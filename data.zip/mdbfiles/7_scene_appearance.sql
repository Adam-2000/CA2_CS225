--Table scene

insert into scene values
    ('Rear Window',1954,1,'Jeffs appartment');
insert into scene values
    ('Rear Window',1954,2,'Private Dramas');
insert into scene values
    ('Rear Window',1954,3,'The Piano Player');
insert into scene values
    ('Rear Window',1954,4,'The Salesman');
insert into scene values
    ('Rear Window',1954,5,'Witness of a murder');
insert into scene values
    ('Rear Window',1954,6,'Lisa in danger');
insert into scene values
    ('Rear Window',1954,7,'Final battle');
insert into scene values
    ('Rear Window',1954,8,'One more broken leg');
insert into scene values
    ('The Birds',1963,1,'Love Birds');
insert into scene values
    ('The Birds',1963,2,'Dogs in front of a pet shop');
insert into scene values
    ('The Birds',1963,3,'Arriving at Bodega Bay');
insert into scene values
    ('The Birds',1963,4,'Gull attack');
insert into scene values
    ('The Birds',1963,5,'Birthday party');
insert into scene values
    ('The Birds',1963,6,'Bird meeting');
insert into scene values
    ('The Birds',1963,7,'At Brenners House');
insert into scene values
    ('The Birds',1963,8,'Open End');
insert into scene values
    ('Psycho',1960,1,'Fed up with life');
insert into scene values
    ('Psycho',1960,2,'40000 dollars for a new start');
insert into scene values
    ('Psycho',1960,3,'Coffee Break');
insert into scene values
    ('Psycho',1960,4,'The Bates Motel');
insert into scene values
    ('Psycho',1960,5,'Norman and Mother');
insert into scene values
    ('Psycho',1960,6,'Taking a shower');
insert into scene values
    ('Psycho',1960,7,'Norman takes over');
insert into scene values
    ('Psycho',1960,8,'Killing mother');
insert into scene values
    ('Traffic',2000,1,'Corruption at Mexican Border');
insert into scene values
    ('Traffic',2000,2,'A new anti-drug czar');
insert into scene values
    ('Traffic',2000,3,'Addicted to Drugs');
insert into scene values
    ('Traffic',2000,4,'Arresting a Baron');
insert into scene values
    ('Traffic',2000,5,'Temptations');
insert into scene values
    ('Traffic',2000,6,'Loosing Caroline');
insert into scene values
    ('Traffic',2000,7,'Taking over the Business');
insert into scene values
    ('Traffic',2000,8,'Untenable Situation');
insert into scene values
    ('Traffic',2000,9,'Assassains');
insert into scene values
    ('Traffic',2000,10,'New Family Values');
insert into scene values
    ('Traffic',2000,11,'The Fight goes on');
insert into scene values
    ('Bullets Over Broadway',1994,1,'gangster');
insert into scene values
    ('Bullets Over Broadway',1994,2,'playwright');
insert into scene values
    ('Bullets Over Broadway',1994,3,'theater');
insert into scene values
    ('Bullets Over Broadway',1994,4,'writing');
insert into scene values
    ('Bullets Over Broadway',1994,5,'murder');
insert into scene values
    ('Bullets Over Broadway',1994,6,'new-york');
insert into scene values
    ('Tombstone',1993,1,'settle down in Tombstone');
insert into scene values
    ('Tombstone',1993,2,'Wyatts brother');
insert into scene values
    ('Tombstone',1993,3,'The Cowboys band');
insert into scene values
    ('Tombstone',1993,4,'problems caused');
insert into scene values
    ('Tombstone',1993,5,'violence region');
insert into scene values
    ('Tombstone',1993,6,'shoot-out at the OK Corral');
insert into scene values
    ('Alice',1990,1,'bored-housewife');
insert into scene values
    ('Alice',1990,2,'infidelity');
insert into scene values
    ('Alice',1990,3,'human-relationship');
insert into scene values
    ('Alice',1990,4,'socialite');
insert into scene values
    ('Alice',1990,5,'christmas');
insert into scene values
    ('Alice',1990,6,'gossip');
insert into scene values
    ('Alice',1990,7,'invisible-man');
insert into scene values
    ('Alice',1990,8,'invisible');
insert into scene values
    ('Mermaids',1990,1,'failed relationship');
insert into scene values
    ('Mermaids',1990,2,'move to east coast');
insert into scene values
    ('Mermaids',1990,3,'Charlottes life');
insert into scene values
    ('Mermaids',1990,4,'the church employee');
insert into scene values
    ('Mermaids',1990,5,'mother-daughter relationship');
insert into scene values
    ('Exotica',1994,1,'bay-sitting');
insert into scene values
    ('Exotica',1994,2,'flashback-sequence');
insert into scene values
    ('Exotica',1994,3,'homesexual');
insert into scene values
    ('Exotica',1994,4,'audit');
insert into scene values
    ('Exotica',1994,5,'ticket-scalping');
insert into scene values
    ('Exotica',1994,6,'psychological-drama');
insert into scene values
    ('Exotica',1994,7,'lesbian-scene');
insert into scene values
    ('Exotica',1994,8,'smuggling');
insert into scene values
    ('Red Rock West',1992,1,'money');
insert into scene values
    ('Red Rock West',1992,2,'neo-noir');
insert into scene values
    ('Red Rock West',1992,3,'hitman');
insert into scene values
    ('Red Rock West',1992,4,'sheriff');
insert into scene values
    ('Red Rock West',1992,5,'murder');
insert into scene values
    ('Red Rock West',1992,6,'small-town');
insert into scene values
    ('Red Rock West',1992,7,'railway');
insert into scene values
    ('Red Rock West',1992,8,'train');
insert into scene values
    ('Chaplin',1992,1,'charlie-chaplin');
insert into scene values
    ('Chaplin',1992,2,'hollywood');
insert into scene values
    ('Chaplin',1992,3,'silent-film-maker');
insert into scene values
    ('Chaplin',1992,4,'political-persecution');
insert into scene values
    ('Chaplin',1992,5,'film-making');
insert into scene values
    ('Chaplin',1992,6,'based-on-multiple-works');
insert into scene values
    ('Fearless',1993,1,'car-crash');
insert into scene values
    ('Fearless',1993,2,'isolation');
insert into scene values
    ('Fearless',1993,3,'recovery');
insert into scene values
    ('Fearless',1993,4,'law');
insert into scene values
    ('Fearless',1993,5,'self-confidence');
insert into scene values
    ('Fearless',1993,6,'disaster');
insert into scene values
    ('Fearless',1993,7,'video-game');
insert into scene values
    ('Fearless',1993,8,'airplane-accident');
insert into scene values
    ('Fearless',1993,9,'flashback-sequence');
insert into scene values
    ('Fearless',1993,10,'allergy');
insert into scene values
    ('Fearless',1993,11,'strawberry');
insert into scene values
    ('Threesome',1994,1,'midget');
insert into scene values
    ('Threesome',1994,2,'dormitory');
insert into scene values
    ('Threesome',1994,3,'best-friend');
insert into scene values
    ('Threesome',1994,4,'college');
insert into scene values
    ('Threesome',1994,5,'homosexual');
insert into scene values
    ('Threesome',1994,6,'roommate');
insert into scene values
    ('Threesome',1994,7,'shower-scene');
insert into scene values
    ('Threesome',1994,8,'adult-humor');
insert into scene values
    ('Jungle Fever',1991,1,'racial');
insert into scene values
    ('Jungle Fever',1991,2,'affair');
insert into scene values
    ('Jungle Fever',1991,3,'deception');
insert into scene values
    ('Jungle Fever',1991,4,'interracial-love');
insert into scene values
    ('Jungle Fever',1991,5,'crack-den');
insert into scene values
    ('Jungle Fever',1991,6,'drugs');
insert into scene values
    ('Jungle Fever',1991,7,'new-york');
insert into scene values
    ('Jungle Fever',1991,8,'racism');
insert into scene values
    ('Internal Affairs',1990,1,'corrupt-cop');
insert into scene values
    ('Internal Affairs',1990,2,'internal-affairs');
insert into scene values
    ('Internal Affairs',1990,3,'investigation');
insert into scene values
    ('Internal Affairs',1990,4,'unfaithfulness');
insert into scene values
    ('Internal Affairs',1990,5,'lesbian-cop');
insert into scene values
    ('Internal Affairs',1990,6,'police');
insert into scene values
    ('Single White Female',1992,1,'apartment');
insert into scene values
    ('Single White Female',1992,2,'software');
insert into scene values
    ('Single White Female',1992,3,'notebook');
insert into scene values
    ('Single White Female',1992,4,'personals-column');
insert into scene values
    ('Single White Female',1992,5,'murder');
insert into scene values
    ('Single White Female',1992,6,'psychopath');
insert into scene values
    ('Single White Female',1992,7,'puppy');
insert into scene values
    ('Single White Female',1992,8,'roommate');
insert into scene values
    ('Single White Female',1992,9,'female scene');
insert into scene values
    ('Trust',1990,1,'Marias pregnancy');
insert into scene values
    ('Trust',1990,2,'homeless');
insert into scene values
    ('Trust',1990,3,'Matthew Slaughter');
insert into scene values
    ('Trust',1990,4,'Matthews job');
insert into scene values
    ('Trust',1990,5,'being together');
insert into scene values
    ('Trust',1990,6,'changes');
insert into scene values
    ('Ju Dou',1990,1,'1920s');
insert into scene values
    ('Ju Dou',1990,2,'crippling-accident');
insert into scene values
    ('Ju Dou',1990,3,'factory-owner');
insert into scene values
    ('Ju Dou',1990,4,'feudal-society');
insert into scene values
    ('Ju Dou',1990,5,'impotence');
insert into scene values
    ('Ju Dou',1990,6,'push-cart');
insert into scene values
    ('Ju Dou',1990,7,'sadism');
insert into scene values
    ('Dahong Denglong Gaogao Gua',1991,1,'marriage');
insert into scene values
    ('Dahong Denglong Gaogao Gua',1991,2,'Chens castle');
insert into scene values
    ('Dahong Denglong Gaogao Gua',1991,3,'competition between the wives');
insert into scene values
    ('Dahong Denglong Gaogao Gua',1991,4,'the red lantern');
insert into scene values
    ('Dahong Denglong Gaogao Gua',1991,5,'haircut');
insert into scene values
    ('Dahong Denglong Gaogao Gua',1991,6,'doctor');
insert into scene values
    ('Cyrano de Bergerac',1990,1,'fall in love with Roxane');
insert into scene values
    ('Cyrano de Bergerac',1990,2,'the large nose');
insert into scene values
    ('Cyrano de Bergerac',1990,3,'the letter');
insert into scene values
    ('Cyrano de Bergerac',1990,4,'Christian in love');
insert into scene values
    ('Cyrano de Bergerac',1990,5,'the mistake');
insert into scene values
    ('Manhattan Murder Mystery',1993,1,'blackmail');
insert into scene values
    ('Manhattan Murder Mystery',1993,2,'neighbor');
insert into scene values
    ('Manhattan Murder Mystery',1993,3,'heart-attack');
insert into scene values
    ('Manhattan Murder Mystery',1993,4,'husband-wife-relationship');
insert into scene values
    ('Manhattan Murder Mystery',1993,5,'new-york');
insert into scene values
    ('Manhattan Murder Mystery',1993,6,'publisher');
insert into scene values
    ('Manhattan Murder Mystery',1993,7,'amateur-detective');
insert into scene values
    ('Manhattan Murder Mystery',1993,8,'murder');
insert into scene values
    ('El Mariachi',1992,1,'motorcycle');
insert into scene values
    ('El Mariachi',1992,2,'paper-knife');
insert into scene values
    ('El Mariachi',1992,3,'singer');
insert into scene values
    ('El Mariachi',1992,4,'low-budget');
insert into scene values
    ('El Mariachi',1992,5,'bathtub');
insert into scene values
    ('El Mariachi',1992,6,'guitar');
insert into scene values
    ('El Mariachi',1992,7,'mistaken-identity');
insert into scene values
    ('El Mariachi',1992,8,'dream');
insert into scene values
    ('El Mariachi',1992,9,'guitar-case');
insert into scene values
    ('El Mariachi',1992,10,'hotel');
insert into scene values
    ('Once Were Warriors',1994,1,'marriage');
insert into scene values
    ('Once Were Warriors',1994,2,'rape');
insert into scene values
    ('Once Were Warriors',1994,3,'suicide');
insert into scene values
    ('Once Were Warriors',1994,4,'vulgarity');
insert into scene values
    ('Once Were Warriors',1994,5,'alcohol');
insert into scene values
    ('Once Were Warriors',1994,6,'suicide-by-hanging');
insert into scene values
    ('Priest',1994,1,'Love Birds');
insert into scene values
    ('Priest',1994,2,'Dogs in front of a pet shop');
insert into scene values
    ('Priest',1994,3,'Arriving at Bodega Bay');
insert into scene values
    ('Priest',1994,4,'Gull attack');
insert into scene values
    ('Priest',1994,5,'Birthday party');
insert into scene values
    ('Priest',1994,6,'Bird meeting');
insert into scene values
    ('Priest',1994,7,'At Brenners House');
insert into scene values
    ('Priest',1994,8,'Open End');
insert into scene values
    ('Pump Up the Volum',1990,1,'catholic');
insert into scene values
    ('Pump Up the Volum',1990,2,'controversial');
insert into scene values
    ('Pump Up the Volum',1990,3,'homosexual');
insert into scene values
    ('Pump Up the Volum',1990,4,'incest');
insert into scene values
    ('Pump Up the Volum',1990,5,'priest');
insert into scene values
    ('Pump Up the Volum',1990,6,'religion');
insert into scene values
    ('Benny and Joon',1993,1,'mechanic');
insert into scene values
    ('Benny and Joon',1993,2,'psychiatrist');
insert into scene values
    ('Benny and Joon',1993,3,'mental-illness');
insert into scene values
    ('Benny and Joon',1993,4,'psychoanalysis');
insert into scene values
    ('Benny and Joon',1993,5,'schizophrenia');
insert into scene values
    ('Six Degrees of Separation',1993,1,'bisexual');
insert into scene values
    ('Six Degrees of Separation',1993,2,'homosexual');
insert into scene values
    ('Six Degrees of Separation',1993,3,'impostor');
insert into scene values
    ('Six Degrees of Separation',1993,4,'suicide');
insert into scene values
    ('Six Degrees of Separation',1993,5,'nudity');
insert into scene values
    ('Bawang Bie Ji',1993,1,'peking-opera');
insert into scene values
    ('Bawang Bie Ji',1993,2,'training');
insert into scene values
    ('Bawang Bie Ji',1993,3,'become famous');
insert into scene values
    ('Bawang Bie Ji',1993,4,'prostitution');
insert into scene values
    ('Bawang Bie Ji',1993,5,'japanese-occupation');
insert into scene values
    ('Bawang Bie Ji',1993,6,'communism');
insert into scene values
    ('Bawang Bie Ji',1993,7,'drugs');
insert into scene values
    ('Bawang Bie Ji',1993,8,'culture revolution');
insert into scene values
    ('In the Line of Fire',1993,1,'assassination');
insert into scene values
    ('In the Line of Fire',1993,2,'master-of-disguise');
insert into scene values
    ('In the Line of Fire',1993,3,'president');
insert into scene values
    ('In the Line of Fire',1993,4,'neck-breaking-scene');
insert into scene values
    ('In the Line of Fire',1993,5,'secret-service');
insert into scene values
    ('Heavenly Creatures',1994,1,'schoolgirl');
insert into scene values
    ('Heavenly Creatures',1994,2,'bathtub');
insert into scene values
    ('Heavenly Creatures',1994,3,'make-believe');
insert into scene values
    ('Heavenly Creatures',1994,4,'parent');
insert into scene values
    ('Heavenly Creatures',1994,5,'surreal');
insert into scene values
    ('Heavenly Creatures',1994,6,'murder');
insert into scene values
    ('Hoop Dreams',1994,1,'college');
insert into scene values
    ('Hoop Dreams',1994,2,'ghetto');
insert into scene values
    ('Hoop Dreams',1994,3,'high-school');
insert into scene values
    ('Hoop Dreams',1994,4,'narrated');
insert into scene values
    ('Hoop Dreams',1994,5,'school');
insert into scene values
    ('Seven',1995,1,'detective');
insert into scene values
    ('Seven',1995,2,'seven-deadly-sins');
insert into scene values
    ('Seven',1995,3,'violence');
insert into scene values
    ('Seven',1995,4,'overweight');
insert into scene values
    ('Seven',1995,5,'partner');
insert into scene values
    ('Seven',1995,6,'serial-killer');
insert into scene values
    ('Seven',1995,7,'disturbing');
insert into scene values
    ('Shallow Grave',1994,1,'apartment');
insert into scene values
    ('Shallow Grave',1994,2,'corpse');
insert into scene values
    ('Shallow Grave',1994,3,'death');
insert into scene values
    ('Shallow Grave',1994,4,'friend');
insert into scene values
    ('Shallow Grave',1994,5,'greed');
insert into scene values
    ('Shallow Grave',1994,6,'betrayal');
insert into scene values
    ('French Kiss',1995,1,'wine');
insert into scene values
    ('French Kiss',1995,2,'american-in-paris');
insert into scene values
    ('French Kiss',1995,3,'france');
insert into scene values
    ('French Kiss',1995,4,'human-relaionship');
insert into scene values
    ('French Kiss',1995,5,'paris-france');
insert into scene values
    ('French Kiss',1995,6,'toronto');
insert into scene values
    ('Braindead',1992,1,'1950s');
insert into scene values
    ('Braindead',1992,2,'splatter');
insert into scene values
    ('Braindead',1992,3,'dominatnt-mother');
insert into scene values
    ('Braindead',1992,4,'zombie');
insert into scene values
    ('Braindead',1992,5,'gore');
insert into scene values
    ('Braindead',1992,6,'disturbing');
insert into scene values
    ('Braindead',1992,7,'mutant-baby');
insert into scene values
    ('Braindead',1992,8,'reanimation');
insert into scene values
    ('Braindead',1992,9,'zoo');
insert into scene values
    ('Clerks',1994,1,'necrophilia');
insert into scene values
    ('Clerks',1994,2,'new-jersey');
insert into scene values
    ('Clerks',1994,3,'russian-rock');
insert into scene values
    ('Clerks',1994,4,'snowball');
insert into scene values
    ('Clerks',1994,5,'funeral');
insert into scene values
    ('Clerks',1994,6,'generation-X');
insert into scene values
    ('Clerks',1994,7,'disgruntled-worker');
insert into scene values
    ('Clerks',1994,8,'accidental-necrophilia');
insert into scene values
    ('Apollo 13',1995,1,'astronaut');
insert into scene values
    ('Apollo 13',1995,2,'husband and wife');
insert into scene values
    ('Apollo 13',1995,3,'launch');
insert into scene values
    ('Apollo 13',1995,4,'nasa');
insert into scene values
    ('Apollo 13',1995,5,'lunar-mission');
insert into scene values
    ('Apollo 13',1995,6,'survival');
insert into scene values
    ('Apollo 13',1995,7,'explosion');
insert into scene values
    ('Apollo 13',1995,8,'space-travel');
insert into scene values
    ('Apollo 13',1995,9,'spacecraft');
insert into scene values
    ('Apollo 13',1995,10,'return');
insert into scene values
    ('Reservoir Dogs',1992,1,'car-jacking');
insert into scene values
    ('Reservoir Dogs',1992,2,'hit-and-run');
insert into scene values
    ('Reservoir Dogs',1992,3,'severed-ear');
insert into scene values
    ('Reservoir Dogs',1992,4,'cop-killer');
insert into scene values
    ('Reservoir Dogs',1992,5,'chase');
insert into scene values
    ('Reservoir Dogs',1992,6,'undercover');
insert into scene values
    ('Pulp Fiction',1994,1,'injection');
insert into scene values
    ('Pulp Fiction',1994,2,'dance-contest');
insert into scene values
    ('Pulp Fiction',1994,3,'ganster');
insert into scene values
    ('Pulp Fiction',1994,4,'full-circle');
insert into scene values
    ('Pulp Fiction',1994,5,'boxing');
insert into scene values
    ('Pulp Fiction',1994,6,'taxicab');
insert into scene values
    ('Pulp Fiction',1994,7,'foot-massage');
insert into scene values
    ('Pulp Fiction',1994,8,'hamburger');
insert into scene values
    ('Pulp Fiction',1994,9,'corpse');
insert into scene values
    ('Yinshi Nan Nu',1994,1,'father and daughter');
insert into scene values
    ('Yinshi Nan Nu',1994,2,'dinner');
insert into scene values
    ('Yinshi Nan Nu',1994,3,'life of Jia-Chien');
insert into scene values
    ('Yinshi Nan Nu',1994,4,'in fast food restaurant');
insert into scene values
    ('Yinshi Nan Nu',1994,5,'pregnant');
insert into scene values
    ('Yinshi Nan Nu',1994,6,'family discussion');
insert into scene values
    ('Short Cuts',1993,1,'fishing');
insert into scene values
    ('Short Cuts',1993,2,'helicopter');
insert into scene values
    ('Short Cuts',1993,3,'unfaithfulness');
insert into scene values
    ('Short Cuts',1993,4,'suicide');
insert into scene values
    ('Short Cuts',1993,5,'telepone-sex');
insert into scene values
    ('Short Cuts',1993,6,'chainsaw');
insert into scene values
    ('Short Cuts',1993,7,'earthquake');
insert into scene values
    ('Short Cuts',1993,8,'hospital');
insert into scene values
    ('Legends of the Fall',1994,1,'bear');
insert into scene values
    ('Legends of the Fall',1994,2,'brothers');
insert into scene values
    ('Legends of the Fall',1994,3,'racism');
insert into scene values
    ('Legends of the Fall',1994,4,'the war');
insert into scene values
    ('Legends of the Fall',1994,5,'passion');
insert into scene values
    ('Legends of the Fall',1994,6,'corruption');
insert into scene values
    ('Legends of the Fall',1994,7,'marriage');
insert into scene values
    ('Legends of the Fall',1994,8,'father and son');
insert into scene values
    ('Natural Born Killers',1994,1,'escape');
insert into scene values
    ('Natural Born Killers',1994,2,'snake-bite');
insert into scene values
    ('Natural Born Killers',1994,3,'serial-killer');
insert into scene values
    ('Natural Born Killers',1994,4,'desert');
insert into scene values
    ('Natural Born Killers',1994,5,'prison');
insert into scene values
    ('Natural Born Killers',1994,6,'revenge');
insert into scene values
    ('Natural Born Killers',1994,7,'wedding-ring');
insert into scene values
    ('In the Mouth of Madness',1995,1,'axe');
insert into scene values
    ('In the Mouth of Madness',1995,2,'horro-writer');
insert into scene values
    ('In the Mouth of Madness',1995,3,'lovecraft');
insert into scene values
    ('In the Mouth of Madness',1995,4,'author');
insert into scene values
    ('In the Mouth of Madness',1995,5,'publisher');
insert into scene values
    ('In the Mouth of Madness',1995,6,'asylum');
insert into scene values
    ('In the Mouth of Madness',1995,7,'monster');
insert into scene values
    ('Forrest Gump',1994,1,'running');
insert into scene values
    ('Forrest Gump',1994,2,'folk-singer');
insert into scene values
    ('Forrest Gump',1994,3,'vietnam war');
insert into scene values
    ('Forrest Gump',1994,4,'table-tennis');
insert into scene values
    ('Forrest Gump',1994,5,'hero');
insert into scene values
    ('Forrest Gump',1994,6,'strom');
insert into scene values
    ('Forrest Gump',1994,7,'shrimping');
insert into scene values
    ('Forrest Gump',1994,8,'marathon');
insert into scene values
    ('Forrest Gump',1994,9,'wedding');
insert into scene values
    ('Forrest Gump',1994,10,'cancer');
insert into scene values
    ('Forrest Gump',1994,11,'son');
insert into scene values
    ('Malcolm X',1992,1,'penitentiary');
insert into scene values
    ('Malcolm X',1992,2,'hustler');
insert into scene values
    ('Malcolm X',1992,3,'beach');
insert into scene values
    ('Malcolm X',1992,4,'harlem');
insert into scene values
    ('Malcolm X',1992,5,'streetcar');
insert into scene values
    ('Malcolm X',1992,6,'police-brutality');
insert into scene values
    ('Malcolm X',1992,7,'streetcar');
insert into scene values
    ('Malcolm X',1992,8,'surveillance');
insert into scene values
    ('Malcolm X',1992,9,'train');
insert into scene values
    ('Malcolm X',1992,10,'urban-decay');
insert into scene values
    ('Dead Again',1991,1,'reporter');
insert into scene values
    ('Dead Again',1991,2,'reincarnation');
insert into scene values
    ('Dead Again',1991,3,'scandal');
insert into scene values
    ('Dead Again',1991,4,'opera');
insert into scene values
    ('Dead Again',1991,5,'private-detective');
insert into scene values
    ('Dead Again',1991,6,'wedding');
insert into scene values
    ('Dead Again',1991,7,'amnesia');
insert into scene values
    ('Dead Again',1991,8,'jewelry');
insert into scene values
    ('Jurassic Park',1993,1,'amusement-park');
insert into scene values
    ('Jurassic Park',1993,2,'tropical-island');
insert into scene values
    ('Jurassic Park',1993,3,'tyrannosaurus');
insert into scene values
    ('Jurassic Park',1993,4,'child');
insert into scene values
    ('Jurassic Park',1993,5,'gene-manipulation');
insert into scene values
    ('Jurassic Park',1993,6,'raptor');
insert into scene values
    ('Jurassic Park',1993,7,'computer-cracker');
insert into scene values
    ('Jurassic Park',1993,8,'disaster');
insert into scene values
    ('Jurassic Park',1993,9,'product-placement');
insert into scene values
    ('Clueless',1995,1,'beverly-hills');
insert into scene values
    ('Clueless',1995,2,'high-school');
insert into scene values
    ('Clueless',1995,3,'popularity');
insert into scene values
    ('Clueless',1995,4,'teen');
insert into scene values
    ('Clueless',1995,5,'makeover');
insert into scene values
    ('Clueless',1995,6,'driving test');
insert into scene values
    ('Clueless',1995,7,'wedding');
insert into scene values
    ('Shadowlands',1993,1,'author');
insert into scene values
    ('Shadowlands',1993,2,'the Narnia books');
insert into scene values
    ('Shadowlands',1993,3,'teacher of Oxford');
insert into scene values
    ('Shadowlands',1993,4,'Joy Gresham');
insert into scene values
    ('Shadowlands',1993,5,'love affair');
insert into scene values
    ('Shadowlands',1993,6,'Joy is unwell');
insert into scene values
    ('Shadowlands',1993,7,'life became complicated');
insert into scene values
    ('Amateur',1994,1,'amnesia');
insert into scene values
    ('Amateur',1994,2,'blackmail');
insert into scene values
    ('Amateur',1994,3,'nun');
insert into scene values
    ('Amateur',1994,4,'torture');
insert into scene values
    ('Amateur',1994,5,'pornographer');
insert into scene values
    ('GoodFellas',1990,1,'gangster');
insert into scene values
    ('GoodFellas',1990,2,'prison');
insert into scene values
    ('GoodFellas',1990,3,'heist');
insert into scene values
    ('GoodFellas',1990,4,'paranoia');
insert into scene values
    ('GoodFellas',1990,5,'contraband');
insert into scene values
    ('GoodFellas',1990,6,'mafia');
insert into scene values
    ('GoodFellas',1990,7,'nightclub');
insert into scene values
    ('GoodFellas',1990,8,'cheat-on-wife');
insert into scene values
    ('GoodFellas',1990,9,'organized-crime');
insert into scene values
    ('GoodFellas',1990,10,'witness-protection');
insert into scene values
    ('GoodFellas',1990,11,'christmas');
insert into scene values
    ('Little Women',1994,1,'1860s');
insert into scene values
    ('Little Women',1994,2,'american-civil-war');
insert into scene values
    ('Little Women',1994,3,'neighbor');
insert into scene values
    ('Little Women',1994,4,'sisters');
insert into scene values
    ('Little Women',1994,5,'secret meetings');
insert into scene values
    ('Little Women',1994,6,'party');
insert into scene values
    ('Little Women',1994,7,'father');
insert into scene values
    ('Little Women',1994,8,'piano');
insert into scene values
    ('While You Were Sleeping',1995,1,'family');
insert into scene values
    ('While You Were Sleeping',1995,2,'christmas');
insert into scene values
    ('While You Were Sleeping',1995,3,'winter');
insert into scene values
    ('While You Were Sleeping',1995,4,'coma');
insert into scene values
    ('While You Were Sleeping',1995,5,'financee');
insert into scene values
    ('While You Were Sleeping',1995,6,'loneliness');
insert into scene values
    ('While You Were Sleeping',1995,7,'infatuation');
insert into scene values
    ('While You Were Sleeping',1995,8,'subway');
insert into scene values
    ('While You Were Sleeping',1995,9,'new-year-eve');

--Table APPEARANCE


insert into appearance values
    ('Psycho',1960,'Lila Crane',1);
insert into appearance values
    ('Psycho',1960,'Marion Crane',1);
insert into appearance values
    ('Psycho',1960,'Sam Loomis',1);
insert into appearance values
    ('Psycho',1960,'Lila Crane',2);
insert into appearance values
    ('Psycho',1960,'Lila Crane',3);
insert into appearance values
    ('Psycho',1960,'Marion Crane',3);
insert into appearance values
    ('Psycho',1960,'Man in hat',3);
insert into appearance values
    ('Psycho',1960,'Norman Bates',4);
insert into appearance values
    ('Psycho',1960,'Lila Crane',4);
insert into appearance values
    ('Psycho',1960,'Norman Bates',5);
insert into appearance values
    ('Psycho',1960,'Mother',5);
insert into appearance values
    ('Psycho',1960,'Norman Bates',6);
insert into appearance values
    ('Psycho',1960,'Lila Crane',6);
insert into appearance values
    ('Psycho',1960,'Norman Bates',7);
insert into appearance values
    ('Psycho',1960,'Sam Loomis',7);
insert into appearance values
    ('Psycho',1960,'Marion Crane',7);
insert into appearance values
    ('Psycho',1960,'Lila Crane',7);
insert into appearance values
    ('Psycho',1960,'Norman Bates',8);
insert into appearance values
    ('Psycho',1960,'Mother',8);
insert into appearance values
    ('The Birds',1963,'Mitch Brenner',1);
insert into appearance values
    ('The Birds',1963,'Melanie Daniels',1);
insert into appearance values
    ('The Birds',1963,'Mitch Brenner',2);
insert into appearance values
    ('The Birds',1963,'Man in pet shop',2);
insert into appearance values
    ('The Birds',1963,'Annie Hayworth',3);
insert into appearance values
    ('The Birds',1963,'Melanie Daniels',3);
insert into appearance values
    ('The Birds',1963,'Mitch Brenner',4);
insert into appearance values
    ('The Birds',1963,'Lydia Brenner',4);
insert into appearance values
    ('The Birds',1963,'Melanie Daniels',4);
insert into appearance values
    ('The Birds',1963,'Mitch Brenner',5);
insert into appearance values
    ('The Birds',1963,'Annie Hayworth',5);
insert into appearance values
    ('The Birds',1963,'Melanie Daniels',5);
insert into appearance values
    ('The Birds',1963,'Mitch Brenner',6);
insert into appearance values
    ('The Birds',1963,'Annie Hayworth',6);
insert into appearance values
    ('The Birds',1963,'Melanie Daniels',6);
insert into appearance values
    ('The Birds',1963,'Lydia Brenner',6);
insert into appearance values
    ('The Birds',1963,'Mitch Brenner',7);
insert into appearance values
    ('The Birds',1963,'Melanie Daniels',7);
insert into appearance values
    ('The Birds',1963,'Lydia Brenner',7);
insert into appearance values
    ('The Birds',1963,'Mitch Brenner',8);
insert into appearance values
    ('The Birds',1963,'Melanie Daniels',8);
insert into appearance values
    ('The Birds',1963,'Lydia Brenner',8);
insert into appearance values
    ('Rear Window',1954,'L.B. Jeff Jefferies',1);
insert into appearance values
    ('Rear Window',1954,'L.B. Jeff Jefferies',2);
insert into appearance values
    ('Rear Window',1954,'Lisa Carol Fremont',2);
insert into appearance values
    ('Rear Window',1954,'Lisa Carol Fremont',3);
insert into appearance values
    ('Rear Window',1954,'Clock-Winding Man',3);
insert into appearance values
    ('Rear Window',1954,'Lisa Carol Fremont',4);
insert into appearance values
    ('Rear Window',1954,'Lars Thorwald',4);
insert into appearance values
    ('Rear Window',1954,'L.B. Jeff Jefferies',4);
insert into appearance values
    ('Rear Window',1954,'L.B. Jeff Jefferies',5);
insert into appearance values
    ('Rear Window',1954,'Lars Thorwald',5);
insert into appearance values
    ('Rear Window',1954,'Lisa Carol Fremont',6);
insert into appearance values
    ('Rear Window',1954,'Lars Thorwald',6);
insert into appearance values
    ('Rear Window',1954,'L.B. Jeff Jefferies',7);
insert into appearance values
    ('Rear Window',1954,'Lars Thorwald',7);
insert into appearance values
    ('Rear Window',1954,'L.B. Jeff Jefferies',8);
insert into appearance values
    ('Rear Window',1954,'Lisa Carol Fremont',8);
insert into appearance values
    ('Traffic',2000,'Javier Rodriguez',1);
insert into appearance values
    ('Traffic',2000,'Manolo Sanchez',1);
insert into appearance values
    ('Traffic',2000,'Robert Wakefield',2);
insert into appearance values
    ('Traffic',2000,'Barbara Wakefield',2);
insert into appearance values
    ('Traffic',2000,'Caroline Wakefield',3);
insert into appearance values
    ('Traffic',2000,'Montel Gordon',4);
insert into appearance values
    ('Traffic',2000,'Ray Castro',4);
insert into appearance values
    ('Traffic',2000,'Carlos Ayala',4);
insert into appearance values
    ('Traffic',2000,'Helena Ayala',4);
insert into appearance values
    ('Traffic',2000,'Manolo Sanchez',5);
insert into appearance values
    ('Traffic',2000,'Ray Castro',5);
insert into appearance values
    ('Traffic',2000,'Javier Rodriguez',5);
insert into appearance values
    ('Traffic',2000,'Montel Gordon',5);
insert into appearance values
    ('Traffic',2000,'Robert Wakefield',6);
insert into appearance values
    ('Traffic',2000,'Barbara Wakefield',6);
insert into appearance values
    ('Traffic',2000,'Caroline Wakefield',6);
insert into appearance values
    ('Traffic',2000,'Francisco Flores',6);
insert into appearance values
    ('Traffic',2000,'Montel Gordon',6);
insert into appearance values
    ('Traffic',2000,'Helena Ayala',7);
insert into appearance values
    ('Traffic',2000,'Javier Rodriguez',7);
insert into appearance values
    ('Traffic',2000,'Manolo Sanchez',7);
insert into appearance values
    ('Traffic',2000,'Francisco Flores',7);
insert into appearance values
    ('Traffic',2000,'Javier Rodriguez',8);
insert into appearance values
    ('Traffic',2000,'Manolo Sanchez',8);
insert into appearance values
    ('Traffic',2000,'Robert Wakefield',8);
insert into appearance values
    ('Traffic',2000,'Barbara Wakefield',8);
insert into appearance values
    ('Traffic',2000,'Francisco Flores',9);
insert into appearance values
    ('Traffic',2000,'Robert Wakefield',9);
insert into appearance values
    ('Traffic',2000,'Montel Gordon',9);
insert into appearance values
    ('Traffic',2000,'Carlos Ayala',9);
insert into appearance values
    ('Traffic',2000,'Robert Wakefield',10);
insert into appearance values
    ('Traffic',2000,'Barbara Wakefield',10);
insert into appearance values
    ('Traffic',2000,'Caroline Wakefield',10);
insert into appearance values
    ('Traffic',2000,'Carlos Ayala',10);
insert into appearance values
    ('Traffic',2000,'Montel Gordon',10);
insert into appearance values
    ('Traffic',2000,'Manolo Sanchez',10);
insert into appearance values
    ('Traffic',2000,'Francisco Flores',10);
insert into appearance values
    ('Traffic',2000,'Carlos Ayala',11);
insert into appearance values
    ('Traffic',2000,'Helena Ayala',11);
insert into appearance values
    ('Traffic',2000,'Montel Gordon',11);
insert into appearance values
    ('Bullets Over Broadway',1994,'David Shayne',1);
insert into appearance values
    ('Bullets Over Broadway',1994,'Julian Marx',1);
insert into appearance values
    ('Bullets Over Broadway',1994,'Rocco',1);
insert into appearance values
    ('Bullets Over Broadway',1994,'David Shayne',2);
insert into appearance values
    ('Bullets Over Broadway',1994,'David Shayne',3);
insert into appearance values
    ('Bullets Over Broadway',1994,'Julian Marx',3);
insert into appearance values
    ('Bullets Over Broadway',1994,'Rocco',3);
insert into appearance values
    ('Bullets Over Broadway',1994,'Rocco',4);
insert into appearance values
    ('Bullets Over Broadway',1994,'Julian Marx',4);
insert into appearance values
    ('Bullets Over Broadway',1994,'Rocco',5);
insert into appearance values
    ('Bullets Over Broadway',1994,'David Shayne',6);
insert into appearance values
    ('Bullets Over Broadway',1994,'Julian Marx',6);
insert into appearance values
    ('Tombstone',1993,'Kurt Russell',1);
insert into appearance values
    ('Tombstone',1993,'Val Kilmer',1);
insert into appearance values
    ('Tombstone',1993,'Kurt Russell',2);
insert into appearance values
    ('Tombstone',1993,'Kurt Russell',3);
insert into appearance values
    ('Tombstone',1993,'Val Kilmer',3);
insert into appearance values
    ('Tombstone',1993,'Sam Elliott',3);
insert into appearance values
    ('Tombstone',1993,'Val Kilmer',4);
insert into appearance values
    ('Tombstone',1993,'Sam Elliott',5);
insert into appearance values
    ('Tombstone',1993,'Kurt Russell',5);
insert into appearance values
    ('Tombstone',1993,'Kurt Russell',6);
insert into appearance values
    ('Tombstone',1993,'Sam Elliott',6);
insert into appearance values
    ('Alice',1990,'Joe',1);
insert into appearance values
    ('Alice',1990,'Alice Tate',2);
insert into appearance values
    ('Alice',1990,'Doug Tate',2);
insert into appearance values
    ('Alice',1990,'Joe',3);
insert into appearance values
    ('Alice',1990,'Alice Tate',3);
insert into appearance values
    ('Alice',1990,'Joe',4);
insert into appearance values
    ('Alice',1990,'Doug Tate',4);
insert into appearance values
    ('Alice',1990,'Alice Tate',5);
insert into appearance values
    ('Alice',1990,'Doug Tate',5);
insert into appearance values
    ('Alice',1990,'Joe',6);
insert into appearance values
    ('Alice',1990,'Alice Tate',7);
insert into appearance values
    ('Alice',1990,'Joe',8);
insert into appearance values
    ('Mermaids',1990,'Rachel Flax',1);
insert into appearance values
    ('Mermaids',1990,'Lou Landsky',1);
insert into appearance values
    ('Mermaids',1990,'Lou Landsky',2);
insert into appearance values
    ('Mermaids',1990,'Charlotte Flax',2);
insert into appearance values
    ('Mermaids',1990,'Rachel Flax',3);
insert into appearance values
    ('Mermaids',1990,'Lou Landsky',3);
insert into appearance values
    ('Mermaids',1990,'Charlotte Flax',3);
insert into appearance values
    ('Mermaids',1990,'Rachel Flax',4);
insert into appearance values
    ('Mermaids',1990,'Lou Landsky',4);
insert into appearance values
    ('Mermaids',1990,'Rachel Flax',5);
insert into appearance values
    ('Exotica',1994,'Inspector',1);
insert into appearance values
    ('Exotica',1994,'Thomas Pinto',1);
insert into appearance values
    ('Exotica',1994,'Inspector',2);
insert into appearance values
    ('Exotica',1994,'Inspector',3);
insert into appearance values
    ('Exotica',1994,'Thomas Pinto',3);
insert into appearance values
    ('Exotica',1994,'Christina',3);
insert into appearance values
    ('Exotica',1994,'Thomas Pinto',4);
insert into appearance values
    ('Exotica',1994,'Inspector',5);
insert into appearance values
    ('Exotica',1994,'Christina',5);
insert into appearance values
    ('Exotica',1994,'Christina',6);
insert into appearance values
    ('Exotica',1994,'Inspector',7);
insert into appearance values
    ('Exotica',1994,'Thomas Pinto',8);
insert into appearance values
    ('Red Rock West',1992,'Michael Williams',1);
insert into appearance values
    ('Red Rock West',1992,'Michael Williams',2);
insert into appearance values
    ('Red Rock West',1992,'Jim',2);
insert into appearance values
    ('Red Rock West',1992,'Michael Williams',3);
insert into appearance values
    ('Red Rock West',1992,'Jim',3);
insert into appearance values
    ('Red Rock West',1992,'Jim',4);
insert into appearance values
    ('Red Rock West',1992,'Michael Williams',5);
insert into appearance values
    ('Red Rock West',1992,'Jim',5);
insert into appearance values
    ('Red Rock West',1992,'Jim',6);
insert into appearance values
    ('Red Rock West',1992,'Michael Williams',7);
insert into appearance values
    ('Red Rock West',1992,'Michael Williams',8);
insert into appearance values
    ('Red Rock West',1992,'Jim',8);
insert into appearance values
    ('Chaplin',1992,'Charlie Chaplin',1);
insert into appearance values
    ('Chaplin',1992,'Hannah Chaplin',1);
insert into appearance values
    ('Chaplin',1992,'Sydney Chaplin',1);
insert into appearance values
    ('Chaplin',1992,'Hannah Chaplin',2);
insert into appearance values
    ('Chaplin',1992,'Charlie Chaplin',3);
insert into appearance values
    ('Chaplin',1992,'Sydney Chaplin',3);
insert into appearance values
    ('Chaplin',1992,'Charlie Chaplin',4);
insert into appearance values
    ('Chaplin',1992,'Hannah Chaplin',4);
insert into appearance values
    ('Chaplin',1992,'Sydney Chaplin',5);
insert into appearance values
    ('Chaplin',1992,'Charlie Chaplin',6);
insert into appearance values
    ('Chaplin',1992,'Hannah Chaplin',6);
insert into appearance values
    ('Fearless',1993,'Max Klein',1);
insert into appearance values
    ('Fearless',1993,'Laura Klein',2);
insert into appearance values
    ('Fearless',1993,'Max Klein',3);
insert into appearance values
    ('Fearless',1993,'Max Klein',4);
insert into appearance values
    ('Fearless',1993,'Laura Klein',4);
insert into appearance values
    ('Fearless',1993,'Laura Klein',5);
insert into appearance values
    ('Fearless',1993,'Carla Rodrigo',5);
insert into appearance values
    ('Fearless',1993,'Max Klein',6);
insert into appearance values
    ('Fearless',1993,'Laura Klein',7);
insert into appearance values
    ('Fearless',1993,'Carla Rodrigo',8);
insert into appearance values
    ('Fearless',1993,'Max Klein',9);
insert into appearance values
    ('Fearless',1993,'Laura Klein',10);
insert into appearance values
    ('Fearless',1993,'Max Klein',11);
insert into appearance values
    ('Threesome',1994,'Alex',1);
insert into appearance values
    ('Threesome',1994,'Stuart',1);
insert into appearance values
    ('Threesome',1994,'Stuart',2);
insert into appearance values
    ('Threesome',1994,'Eddy',2);
insert into appearance values
    ('Threesome',1994,'Alex',3);
insert into appearance values
    ('Threesome',1994,'Stuart',3);
insert into appearance values
    ('Threesome',1994,'Alex',4);
insert into appearance values
    ('Threesome',1994,'Stuart',5);
insert into appearance values
    ('Threesome',1994,'Eddy',5);
insert into appearance values
    ('Threesome',1994,'Alex',6);
insert into appearance values
    ('Threesome',1994,'Stuart',7);
insert into appearance values
    ('Threesome',1994,'Alex',8);
insert into appearance values
    ('Jungle Fever',1991,'Flipper Purify',1);
insert into appearance values
    ('Jungle Fever',1991,'Flipper Purify',2);
insert into appearance values
    ('Jungle Fever',1991,'Angie Tucci',2);
insert into appearance values
    ('Jungle Fever',1991,'Flipper Purify',3);
insert into appearance values
    ('Jungle Fever',1991,'Angie Tucci',3);
insert into appearance values
    ('Jungle Fever',1991,'Flipper Purify',4);
insert into appearance values
    ('Jungle Fever',1991,'Angie Tucci',4);
insert into appearance values
    ('Jungle Fever',1991,'Flipper Purify',5);
insert into appearance values
    ('Jungle Fever',1991,'Angie Tucci',6);
insert into appearance values
    ('Jungle Fever',1991,'Flipper Purify',7);
insert into appearance values
    ('Jungle Fever',1991,'Angie Tucci',8);
insert into appearance values
    ('Internal Affairs',1990,'Dennis Peck',1);
insert into appearance values
    ('Internal Affairs',1990,'Raymond Avila',1);
insert into appearance values
    ('Internal Affairs',1990,'Kathleen Avila',1);
insert into appearance values
    ('Internal Affairs',1990,'Dennis Peck',2);
insert into appearance values
    ('Internal Affairs',1990,'Raymond Avila',2);
insert into appearance values
    ('Internal Affairs',1990,'Raymond Avila',3);
insert into appearance values
    ('Internal Affairs',1990,'Kathleen Avila',3);
insert into appearance values
    ('Internal Affairs',1990,'Dennis Peck',4);
insert into appearance values
    ('Internal Affairs',1990,'Raymond Avila',5);
insert into appearance values
    ('Internal Affairs',1990,'Kathleen Avila',5);
insert into appearance values
    ('Internal Affairs',1990,'Dennis Peck',6);
insert into appearance values
    ('Internal Affairs',1990,'Kathleen Avila',6);
insert into appearance values
    ('Single White Female',1992,'Allison Jones',1);
insert into appearance values
    ('Single White Female',1992,'Hedra Carlson',2);
insert into appearance values
    ('Single White Female',1992,'Allison Jones',3);
insert into appearance values
    ('Single White Female',1992,'Allison Jones',4);
insert into appearance values
    ('Single White Female',1992,'Hedra Carlson',4);
insert into appearance values
    ('Single White Female',1992,'Sam Rawson',5);
insert into appearance values
    ('Single White Female',1992,'Allison Jones',6);
insert into appearance values
    ('Single White Female',1992,'Sam Rawson',6);
insert into appearance values
    ('Single White Female',1992,'Sam Rawson',7);
insert into appearance values
    ('Single White Female',1992,'Allison Jones',8);
insert into appearance values
    ('Single White Female',1992,'Hedra Carlson',8);
insert into appearance values
    ('Single White Female',1992,'Allison Jones',9);
insert into appearance values
    ('Trust',1990,'Maria Coughlin',1);
insert into appearance values
    ('Trust',1990,'Matthew Slaughter',1);
insert into appearance values
    ('Trust',1990,'Maria Coughlin',2);
insert into appearance values
    ('Trust',1990,'Matthew Slaughter',2);
insert into appearance values
    ('Trust',1990,'Maria Coughlin',3);
insert into appearance values
    ('Trust',1990,'Matthew Slaughter',3);
insert into appearance values
    ('Trust',1990,'Matthew Slaughter',4);
insert into appearance values
    ('Trust',1990,'Maria Coughlin',5);
insert into appearance values
    ('Trust',1990,'Matthew Slaughter',5);
insert into appearance values
    ('Trust',1990,'Maria Coughlin',6);
insert into appearance values
    ('Ju Dou',1990,'Ju Dou',1);
insert into appearance values
    ('Ju Dou',1990,'Yang Tian-qing',1);
insert into appearance values
    ('Ju Dou',1990,'Ju Dou',2);
insert into appearance values
    ('Ju Dou',1990,'Yang Tian-qing',2);
insert into appearance values
    ('Ju Dou',1990,'Ju Dou',3);
insert into appearance values
    ('Ju Dou',1990,'Yang Tian-qing',3);
insert into appearance values
    ('Ju Dou',1990,'Ju Dou',4);
insert into appearance values
    ('Ju Dou',1990,'Yang Tian-qing',4);
insert into appearance values
    ('Ju Dou',1990,'Ju Dou',5);
insert into appearance values
    ('Ju Dou',1990,'Yang Tian-qing',5);
insert into appearance values
    ('Ju Dou',1990,'Ju Dou',6);
insert into appearance values
    ('Ju Dou',1990,'Yang Tian-qing',7);
insert into appearance values
    ('Dahong Denglong Gaogao Gua',1991,'Songlian',1);
insert into appearance values
    ('Dahong Denglong Gaogao Gua',1991,'The Master',1);
insert into appearance values
    ('Dahong Denglong Gaogao Gua',1991,'The Third Concubine',2);
insert into appearance values
    ('Dahong Denglong Gaogao Gua',1991,'The Master',2);
insert into appearance values
    ('Dahong Denglong Gaogao Gua',1991,'Songlian',3);
insert into appearance values
    ('Dahong Denglong Gaogao Gua',1991,'The Third Concubine',3);
insert into appearance values
    ('Dahong Denglong Gaogao Gua',1991,'Songlian',4);
insert into appearance values
    ('Dahong Denglong Gaogao Gua',1991,'Songlian',5);
insert into appearance values
    ('Dahong Denglong Gaogao Gua',1991,'The Third Concubine',5);
insert into appearance values
    ('Dahong Denglong Gaogao Gua',1991,'Songlian',6);
insert into appearance values
    ('Dahong Denglong Gaogao Gua',1991,'The Master',6);
insert into appearance values
    ('Cyrano de Bergerac',1990,'Cyrano De Bergerac',1);
insert into appearance values
    ('Cyrano de Bergerac',1990,'Roxane',1);
insert into appearance values
    ('Cyrano de Bergerac',1990,'Cyrano De Bergerac',2);
insert into appearance values
    ('Cyrano de Bergerac',1990,'Roxane',2);
insert into appearance values
    ('Cyrano de Bergerac',1990,'Cyrano De Bergerac',3);
insert into appearance values
    ('Cyrano de Bergerac',1990,'Cyrano De Bergerac',4);
insert into appearance values
    ('Cyrano de Bergerac',1990,'Roxane',4);
insert into appearance values
    ('Cyrano de Bergerac',1990,'Cyrano De Bergerac',5);
insert into appearance values
    ('Cyrano de Bergerac',1990,'Roxane',5);
insert into appearance values
    ('Manhattan Murder Mystery',1993,'Larry Lipton',1);
insert into appearance values
    ('Manhattan Murder Mystery',1993,'Larry Lipton',2);
insert into appearance values
    ('Manhattan Murder Mystery',1993,'Carol Lipton',2);
insert into appearance values
    ('Manhattan Murder Mystery',1993,'Larry Lipton',3);
insert into appearance values
    ('Manhattan Murder Mystery',1993,'Carol Lipton',3);
insert into appearance values
    ('Manhattan Murder Mystery',1993,'Larry Lipton',4);
insert into appearance values
    ('Manhattan Murder Mystery',1993,'Carol Lipton',4);
insert into appearance values
    ('Manhattan Murder Mystery',1993,'Larry Lipton',5);
insert into appearance values
    ('Manhattan Murder Mystery',1993,'Carol Lipton',6);
insert into appearance values
    ('Manhattan Murder Mystery',1993,'Larry Lipton',7);
insert into appearance values
    ('Manhattan Murder Mystery',1993,'Larry Lipton',8);
insert into appearance values
    ('Manhattan Murder Mystery',1993,'Carol Lipton',8);
insert into appearance values
    ('El Mariachi',1992,'El Mariachi',1);
insert into appearance values
    ('El Mariachi',1992,'Domino',1);
insert into appearance values
    ('El Mariachi',1992,'El Mariachi',2);
insert into appearance values
    ('El Mariachi',1992,'El Mariachi',3);
insert into appearance values
    ('El Mariachi',1992,'Domino',3);
insert into appearance values
    ('El Mariachi',1992,'Domino',4);
insert into appearance values
    ('El Mariachi',1992,'El Mariachi',5);
insert into appearance values
    ('El Mariachi',1992,'El Mariachi',6);
insert into appearance values
    ('El Mariachi',1992,'Domino',6);
insert into appearance values
    ('El Mariachi',1992,'Domino',7);
insert into appearance values
    ('El Mariachi',1992,'El Mariachi',8);
insert into appearance values
    ('El Mariachi',1992,'Domino',9);
insert into appearance values
    ('El Mariachi',1992,'El Mariachi',10);
insert into appearance values
    ('El Mariachi',1992,'Domino',10);
insert into appearance values
    ('Once Were Warriors',1994,'Beth Heke',1);
insert into appearance values
    ('Once Were Warriors',1994,'Jake Heke',1);
insert into appearance values
    ('Once Were Warriors',1994,'Beth Heke',2);
insert into appearance values
    ('Once Were Warriors',1994,'Jake Heke',2);
insert into appearance values
    ('Once Were Warriors',1994,'Beth Heke',3);
insert into appearance values
    ('Once Were Warriors',1994,'Jake Heke',3);
insert into appearance values
    ('Once Were Warriors',1994,'Jake Heke',4);
insert into appearance values
    ('Once Were Warriors',1994,'Beth Heke',5);
insert into appearance values
    ('Once Were Warriors',1994,'Jake Heke',5);
insert into appearance values
    ('Once Were Warriors',1994,'Beth Heke',6);
insert into appearance values
    ('Once Were Warriors',1994,'Jake Heke',6);
insert into appearance values
    ('Priest',1994,'Father Greg Pilkington',1);
insert into appearance values
    ('Priest',1994,'Father Matthew Thomas',2);
insert into appearance values
    ('Priest',1994,'Father Greg Pilkington',3);
insert into appearance values
    ('Priest',1994,'Father Matthew Thomas',3);
insert into appearance values
    ('Priest',1994,'Father Greg Pilkington',4);
insert into appearance values
    ('Priest',1994,'Father Greg Pilkington',5);
insert into appearance values
    ('Priest',1994,'Father Matthew Thomas',5);
insert into appearance values
    ('Priest',1994,'Father Matthew Thomas',6);
insert into appearance values
    ('Priest',1994,'Father Greg Pilkington',7);
insert into appearance values
    ('Priest',1994,'Father Matthew Thomas',7);
insert into appearance values
    ('Priest',1994,'Father Greg Pilkington',8);
insert into appearance values
    ('Pump Up the Volum',1990,'Mark Hunter',1);
insert into appearance values
    ('Pump Up the Volum',1990,'Nora Diniro',1);
insert into appearance values
    ('Pump Up the Volum',1990,'Mark Hunter',2);
insert into appearance values
    ('Pump Up the Volum',1990,'Nora Diniro',2);
insert into appearance values
    ('Pump Up the Volum',1990,'Mark Hunter',3);
insert into appearance values
    ('Pump Up the Volum',1990,'Nora Diniro',3);
insert into appearance values
    ('Pump Up the Volum',1990,'Mark Hunter',4);
insert into appearance values
    ('Pump Up the Volum',1990,'Nora Diniro',4);
insert into appearance values
    ('Pump Up the Volum',1990,'Mark Hunter',5);
insert into appearance values
    ('Pump Up the Volum',1990,'Nora Diniro',5);
insert into appearance values
    ('Pump Up the Volum',1990,'Mark Hunter',6);
insert into appearance values
    ('Benny and Joon',1993,'Sam',1);
insert into appearance values
    ('Benny and Joon',1993,'Juniper Pearl',1);
insert into appearance values
    ('Benny and Joon',1993,'Sam',2);
insert into appearance values
    ('Benny and Joon',1993,'Juniper Pearl',2);
insert into appearance values
    ('Benny and Joon',1993,'Sam',3);
insert into appearance values
    ('Benny and Joon',1993,'Juniper Pearl',3);
insert into appearance values
    ('Benny and Joon',1993,'Sam',4);
insert into appearance values
    ('Benny and Joon',1993,'Juniper Pearl',4);
insert into appearance values
    ('Benny and Joon',1993,'Sam',5);
insert into appearance values
    ('Benny and Joon',1993,'Juniper Pearl',5);
insert into appearance values
    ('Six Degrees of Separation',1993,'Ouisa Kittredge',1);
insert into appearance values
    ('Six Degrees of Separation',1993,'Paul',1);
insert into appearance values
    ('Six Degrees of Separation',1993,'John Flanders',2);
insert into appearance values
    ('Six Degrees of Separation',1993,'Ouisa Kittredge',3);
insert into appearance values
    ('Six Degrees of Separation',1993,'Paul',3);
insert into appearance values
    ('Six Degrees of Separation',1993,'John Flanders',3);
insert into appearance values
    ('Six Degrees of Separation',1993,'Ouisa Kittredge',4);
insert into appearance values
    ('Six Degrees of Separation',1993,'Paul',4);
insert into appearance values
    ('Six Degrees of Separation',1993,'John Flanders',4);
insert into appearance values
    ('Six Degrees of Separation',1993,'Ouisa Kittredge',5);
insert into appearance values
    ('Six Degrees of Separation',1993,'Paul',5);
insert into appearance values
    ('Bawang Bie Ji',1993,'Cheng Dieyi',1);
insert into appearance values
    ('Bawang Bie Ji',1993,'Duan Xiaolou',2);
insert into appearance values
    ('Bawang Bie Ji',1993,'Cheng Dieyi',3);
insert into appearance values
    ('Bawang Bie Ji',1993,'Duan Xiaolou',3);
insert into appearance values
    ('Bawang Bie Ji',1993,'Cheng Dieyi',4);
insert into appearance values
    ('Bawang Bie Ji',1993,'Juxian',4);
insert into appearance values
    ('Bawang Bie Ji',1993,'Duan Xiaolou',5);
insert into appearance values
    ('Bawang Bie Ji',1993,'Juxian',5);
insert into appearance values
    ('Bawang Bie Ji',1993,'Cheng Dieyi',6);
insert into appearance values
    ('Bawang Bie Ji',1993,'Duan Xiaolou',6);
insert into appearance values
    ('Bawang Bie Ji',1993,'Juxian',7);
insert into appearance values
    ('Bawang Bie Ji',1993,'Cheng Dieyi',8);
insert into appearance values
    ('In the Line of Fire',1993,'Secret Service Agent Frank Horrigan',1);
insert into appearance values
    ('In the Line of Fire',1993,'Mitch Leary',1);
insert into appearance values
    ('In the Line of Fire',1993,'Secret Service Agent Lilly Raines',1);
insert into appearance values
    ('In the Line of Fire',1993,'Secret Service Agent Frank Horrigan',2);
insert into appearance values
    ('In the Line of Fire',1993,'Secret Service Agent Lilly Raines',2);
insert into appearance values
    ('In the Line of Fire',1993,'Mitch Leary',3);
insert into appearance values
    ('In the Line of Fire',1993,'Secret Service Agent Frank Horrigan',4);
insert into appearance values
    ('In the Line of Fire',1993,'Secret Service Agent Lilly Raines',4);
insert into appearance values
    ('In the Line of Fire',1993,'Secret Service Agent Frank Horrigan',5);
insert into appearance values
    ('In the Line of Fire',1993,'Mitch Leary',5);
insert into appearance values
    ('In the Line of Fire',1993,'Secret Service Agent Lilly Raines',5);
insert into appearance values
    ('Heavenly Creatures',1994,'Pauline Yvonne Rieper',1);
insert into appearance values
    ('Heavenly Creatures',1994,'Juliet Marion Hulme',1);
insert into appearance values
    ('Heavenly Creatures',1994,'Pauline Yvonne Rieper',2);
insert into appearance values
    ('Heavenly Creatures',1994,'Juliet Marion Hulme',2);
insert into appearance values
    ('Heavenly Creatures',1994,'Pauline Yvonne Rieper',3);
insert into appearance values
    ('Heavenly Creatures',1994,'Juliet Marion Hulme',3);
insert into appearance values
    ('Heavenly Creatures',1994,'Pauline Yvonne Rieper',4);
insert into appearance values
    ('Heavenly Creatures',1994,'Juliet Marion Hulme',4);
insert into appearance values
    ('Heavenly Creatures',1994,'Pauline Yvonne Rieper',5);
insert into appearance values
    ('Heavenly Creatures',1994,'Pauline Yvonne Rieper',6);
insert into appearance values
    ('Heavenly Creatures',1994,'Juliet Marion Hulme',6);
insert into appearance values
    ('Hoop Dreams',1994,'Himself',1);
insert into appearance values
    ('Hoop Dreams',1994,'Himself',2);
insert into appearance values
    ('Hoop Dreams',1994,'Himself',3);
insert into appearance values
    ('Hoop Dreams',1994,'Himself',4);
insert into appearance values
    ('Hoop Dreams',1994,'Himself',5);
insert into appearance values
    ('Seven',1995,'Detective William Somerset',1);
insert into appearance values
    ('Seven',1995,'Detective William Somerset',2);
insert into appearance values
    ('Seven',1995,'Detective David Mills',2);
insert into appearance values
    ('Seven',1995,'Detective William Somerset',3);
insert into appearance values
    ('Seven',1995,'Detective David Mills',3);
insert into appearance values
    ('Seven',1995,'Detective William Somerset',4);
insert into appearance values
    ('Seven',1995,'Detective David Mills',4);
insert into appearance values
    ('Seven',1995,'Detective William Somerset',5);
insert into appearance values
    ('Seven',1995,'Detective David Mills',5);
insert into appearance values
    ('Seven',1995,'Detective David Mills',6);
insert into appearance values
    ('Seven',1995,'Detective William Somerset',7);
insert into appearance values
    ('Seven',1995,'Detective David Mills',7);
insert into appearance values
    ('Shallow Grave',1994,'Juliet Miller',1);
insert into appearance values
    ('Shallow Grave',1994,'David Stephens',1);
insert into appearance values
    ('Shallow Grave',1994,'Alex Law',1);
insert into appearance values
    ('Shallow Grave',1994,'Juliet Miller',2);
insert into appearance values
    ('Shallow Grave',1994,'David Stephens',2);
insert into appearance values
    ('Shallow Grave',1994,'Alex Law',2);
insert into appearance values
    ('Shallow Grave',1994,'David Stephens',3);
insert into appearance values
    ('Shallow Grave',1994,'Juliet Miller',4);
insert into appearance values
    ('Shallow Grave',1994,'David Stephens',5);
insert into appearance values
    ('Shallow Grave',1994,'Alex Law',5);
insert into appearance values
    ('Shallow Grave',1994,'Juliet Miller',6);
insert into appearance values
    ('Shallow Grave',1994,'David Stephens',6);
insert into appearance values
    ('French Kiss',1995,'Kate',1);
insert into appearance values
    ('French Kiss',1995,'Luc Teyssier',1);
insert into appearance values
    ('French Kiss',1995,'Kate',2);
insert into appearance values
    ('French Kiss',1995,'Luc Teyssier',2);
insert into appearance values
    ('French Kiss',1995,'Luc Teyssier',3);
insert into appearance values
    ('French Kiss',1995,'Charlie',3);
insert into appearance values
    ('French Kiss',1995,'Kate',4);
insert into appearance values
    ('French Kiss',1995,'Luc Teyssier',4);
insert into appearance values
    ('French Kiss',1995,'Charlie',5);
insert into appearance values
    ('French Kiss',1995,'Kate',6);
insert into appearance values
    ('French Kiss',1995,'Luc Teyssier',6);
insert into appearance values
    ('Braindead',1992,'Lionel Cosgrove',1);
insert into appearance values
    ('Braindead',1992,'Paquita Maria Sanchez',2);
insert into appearance values
    ('Braindead',1992,'Mum',2);
insert into appearance values
    ('Braindead',1992,'Lionel Cosgrove',3);
insert into appearance values
    ('Braindead',1992,'Paquita Maria Sanchez',4);
insert into appearance values
    ('Braindead',1992,'Mum',4);
insert into appearance values
    ('Braindead',1992,'Undertaker Assistant',5);
insert into appearance values
    ('Braindead',1992,'Lionel Cosgrove',6);
insert into appearance values
    ('Braindead',1992,'Paquita Maria Sanchez',6);
insert into appearance values
    ('Braindead',1992,'Undertaker Assistant',7);
insert into appearance values
    ('Braindead',1992,'Undertaker Assistant',8);
insert into appearance values
    ('Braindead',1992,'Mum',9);
insert into appearance values
    ('Clerks',1994,'Veronica Loughran',1);
insert into appearance values
    ('Clerks',1994,'Caitlin Bree',1);
insert into appearance values
    ('Clerks',1994,'Veronica Loughran',2);
insert into appearance values
    ('Clerks',1994,'Veronica Loughran',3);
insert into appearance values
    ('Clerks',1994,'Caitlin Bree',3);
insert into appearance values
    ('Clerks',1994,'Veronica Loughran',4);
insert into appearance values
    ('Clerks',1994,'Caitlin Bree',4);
insert into appearance values
    ('Clerks',1994,'Veronica Loughran',5);
insert into appearance values
    ('Clerks',1994,'Caitlin Bree',5);
insert into appearance values
    ('Clerks',1994,'Caitlin Bree',6);
insert into appearance values
    ('Clerks',1994,'Veronica Loughran',7);
insert into appearance values
    ('Clerks',1994,'Caitlin Bree',8);
insert into appearance values
    ('Apollo 13',1995,'Jim Lovell',1);
insert into appearance values
    ('Apollo 13',1995,'Fred Haise',2);
insert into appearance values
    ('Apollo 13',1995,'Jack Swigert',2);
insert into appearance values
    ('Apollo 13',1995,'Jim Lovell',3);
insert into appearance values
    ('Apollo 13',1995,'Fred Haise',4);
insert into appearance values
    ('Apollo 13',1995,'Jack Swigert',4);
insert into appearance values
    ('Apollo 13',1995,'Jim Lovell',5);
insert into appearance values
    ('Apollo 13',1995,'Fred Haise',6);
insert into appearance values
    ('Apollo 13',1995,'Jim Lovell',7);
insert into appearance values
    ('Apollo 13',1995,'Jack Swigert',8);
insert into appearance values
    ('Apollo 13',1995,'Jim Lovell',9);
insert into appearance values
    ('Apollo 13',1995,'Fred Haise',9);
insert into appearance values
    ('Apollo 13',1995,'Jack Swigert',10);
insert into appearance values
    ('Reservoir Dogs',1992,'Larry',1);
insert into appearance values
    ('Reservoir Dogs',1992,'Freddy',2);
insert into appearance values
    ('Reservoir Dogs',1992,'Larry',3);
insert into appearance values
    ('Reservoir Dogs',1992,'Vic',3);
insert into appearance values
    ('Reservoir Dogs',1992,'Freddy',4);
insert into appearance values
    ('Reservoir Dogs',1992,'Vic',4);
insert into appearance values
    ('Reservoir Dogs',1992,'Larry',5);
insert into appearance values
    ('Reservoir Dogs',1992,'Freddy',6);
insert into appearance values
    ('Reservoir Dogs',1992,'Vic',6);
insert into appearance values
    ('Pulp Fiction',1994,'Vincent Vega',1);
insert into appearance values
    ('Pulp Fiction',1994,'Jules Winnfield',1);
insert into appearance values
    ('Pulp Fiction',1994,'Vincent Vega',2);
insert into appearance values
    ('Pulp Fiction',1994,'Jules Winnfield',3);
insert into appearance values
    ('Pulp Fiction',1994,'Winston Wolf',3);
insert into appearance values
    ('Pulp Fiction',1994,'Vincent Vega',4);
insert into appearance values
    ('Pulp Fiction',1994,'Jules Winnfield',5);
insert into appearance values
    ('Pulp Fiction',1994,'Vincent Vega',6);
insert into appearance values
    ('Pulp Fiction',1994,'Vincent Vega',7);
insert into appearance values
    ('Pulp Fiction',1994,'Winston Wolf',7);
insert into appearance values
    ('Pulp Fiction',1994,'Winston Wolf',8);
insert into appearance values
    ('Pulp Fiction',1994,'Jules Winnfield',9);
insert into appearance values
    ('Yinshi Nan Nu',1994,'Chu',1);
insert into appearance values
    ('Yinshi Nan Nu',1994,'Jia-Ning',2);
insert into appearance values
    ('Yinshi Nan Nu',1994,'Jia-Chien',2);
insert into appearance values
    ('Yinshi Nan Nu',1994,'Chu',3);
insert into appearance values
    ('Yinshi Nan Nu',1994,'Jia-Chien',3);
insert into appearance values
    ('Yinshi Nan Nu',1994,'Chu',4);
insert into appearance values
    ('Yinshi Nan Nu',1994,'Jia-Chien',4);
insert into appearance values
    ('Yinshi Nan Nu',1994,'Chu',5);
insert into appearance values
    ('Yinshi Nan Nu',1994,'Jia-Ning',5);
insert into appearance values
    ('Yinshi Nan Nu',1994,'Jia-Chien',5);
insert into appearance values
    ('Yinshi Nan Nu',1994,'Chu',6);
insert into appearance values
    ('Yinshi Nan Nu',1994,'Jia-Chien',6);
insert into appearance values
    ('Short Cuts',1993,'Ann Finnigan',1);
insert into appearance values
    ('Short Cuts',1993,'Howard Finnigan',2);
insert into appearance values
    ('Short Cuts',1993,'Ann Finnigan',3);
insert into appearance values
    ('Short Cuts',1993,'Paul Finnigan',3);
insert into appearance values
    ('Short Cuts',1993,'Howard Finnigan',4);
insert into appearance values
    ('Short Cuts',1993,'Ann Finnigan',5);
insert into appearance values
    ('Short Cuts',1993,'Paul Finnigan',5);
insert into appearance values
    ('Short Cuts',1993,'Paul Finnigan',6);
insert into appearance values
    ('Short Cuts',1993,'Howard Finnigan',7);
insert into appearance values
    ('Short Cuts',1993,'Paul Finnigan',7);
insert into appearance values
    ('Short Cuts',1993,'Ann Finnigan',8);
insert into appearance values
    ('Short Cuts',1993,'Paul Finnigan',8);
insert into appearance values
    ('Legends of the Fall',1994,'Tristan Ludlow',1);
insert into appearance values
    ('Legends of the Fall',1994,'Colonel William Ludlow',1);
insert into appearance values
    ('Legends of the Fall',1994,'Tristan Ludlow',2);
insert into appearance values
    ('Legends of the Fall',1994,'Alfred Ludlow',2);
insert into appearance values
    ('Legends of the Fall',1994,'Colonel William Ludlow',3);
insert into appearance values
    ('Legends of the Fall',1994,'Tristan Ludlow',4);
insert into appearance values
    ('Legends of the Fall',1994,'Colonel William Ludlow',5);
insert into appearance values
    ('Legends of the Fall',1994,'Alfred Ludlow',5);
insert into appearance values
    ('Legends of the Fall',1994,'Tristan Ludlow',6);
insert into appearance values
    ('Legends of the Fall',1994,'Alfred Ludlow',7);
insert into appearance values
    ('Legends of the Fall',1994,'Tristan Ludlow',8);
insert into appearance values
    ('Legends of the Fall',1994,'Colonel William Ludlow',8);
insert into appearance values
    ('Natural Born Killers',1994,'Mickey Knox',1);
insert into appearance values
    ('Natural Born Killers',1994,'Mallory Wilson Knox',1);
insert into appearance values
    ('Natural Born Killers',1994,'Wayne Gale',2);
insert into appearance values
    ('Natural Born Killers',1994,'Mickey Knox',3);
insert into appearance values
    ('Natural Born Killers',1994,'Mallory Wilson Knox',3);
insert into appearance values
    ('Natural Born Killers',1994,'Mickey Knox',4);
insert into appearance values
    ('Natural Born Killers',1994,'Mallory Wilson Knox',5);
insert into appearance values
    ('Natural Born Killers',1994,'Wayne Gale',5);
insert into appearance values
    ('Natural Born Killers',1994,'Mickey Knox',6);
insert into appearance values
    ('Natural Born Killers',1994,'Wayne Gale',6);
insert into appearance values
    ('Natural Born Killers',1994,'Mickey Knox',7);
insert into appearance values
    ('Natural Born Killers',1994,'Mallory Wilson Knox',7);
insert into appearance values
    ('In the Mouth of Madness',1995,'John Trent',1);
insert into appearance values
    ('In the Mouth of Madness',1995,'Sutter Cane',1);
insert into appearance values
    ('In the Mouth of Madness',1995,'Sutter Cane',2);
insert into appearance values
    ('In the Mouth of Madness',1995,'John Trent',3);
insert into appearance values
    ('In the Mouth of Madness',1995,'Linda Styles',3);
insert into appearance values
    ('In the Mouth of Madness',1995,'Sutter Cane',4);
insert into appearance values
    ('In the Mouth of Madness',1995,'Linda Styles',4);
insert into appearance values
    ('In the Mouth of Madness',1995,'John Trent',5);
insert into appearance values
    ('In the Mouth of Madness',1995,'Linda Styles',5);
insert into appearance values
    ('In the Mouth of Madness',1995,'Sutter Cane',6);
insert into appearance values
    ('In the Mouth of Madness',1995,'John Trent',7);
insert into appearance values
    ('Forrest Gump',1994,'Forrest Gump',1);
insert into appearance values
    ('Forrest Gump',1994,'Forrest Gump',2);
insert into appearance values
    ('Forrest Gump',1994,'Forrest Gump',3);
insert into appearance values
    ('Forrest Gump',1994,'Jenny Curran',3);
insert into appearance values
    ('Forrest Gump',1994,'Lieutenant Daniel Taylor',4);
insert into appearance values
    ('Forrest Gump',1994,'Forrest Gump',5);
insert into appearance values
    ('Forrest Gump',1994,'Jenny Curran',5);
insert into appearance values
    ('Forrest Gump',1994,'Lieutenant Daniel Taylor',6);
insert into appearance values
    ('Forrest Gump',1994,'Forrest Gump',7);
insert into appearance values
    ('Forrest Gump',1994,'Lieutenant Daniel Taylor',7);
insert into appearance values
    ('Forrest Gump',1994,'Forrest Gump',8);
insert into appearance values
    ('Forrest Gump',1994,'Lieutenant Daniel Taylor',9);
insert into appearance values
    ('Forrest Gump',1994,'Forrest Gump',10);
insert into appearance values
    ('Forrest Gump',1994,'Jenny Curran',11);
insert into appearance values
    ('Malcolm X',1992,'Malcolm X',1);
insert into appearance values
    ('Malcolm X',1992,'Betty Shabazz',1);
insert into appearance values
    ('Malcolm X',1992,'Shorty',2);
insert into appearance values
    ('Malcolm X',1992,'Malcolm X',3);
insert into appearance values
    ('Malcolm X',1992,'Betty Shabazz',3);
insert into appearance values
    ('Malcolm X',1992,'Shorty',4);
insert into appearance values
    ('Malcolm X',1992,'Malcolm X',5);
insert into appearance values
    ('Malcolm X',1992,'Betty Shabazz',6);
insert into appearance values
    ('Malcolm X',1992,'Malcolm X',7);
insert into appearance values
    ('Malcolm X',1992,'Shorty',7);
insert into appearance values
    ('Malcolm X',1992,'Shorty',8);
insert into appearance values
    ('Malcolm X',1992,'Malcolm X',9);
insert into appearance values
    ('Malcolm X',1992,'Malcolm X',10);
insert into appearance values
    ('Malcolm X',1992,'Betty Shabazz',10);
insert into appearance values
    ('Dead Again',1991,'Mike Church',1);
insert into appearance values
    ('Dead Again',1991,'Gray Baker',2);
insert into appearance values
    ('Dead Again',1991,'Margaret Strauss',2);
insert into appearance values
    ('Dead Again',1991,'Mike Church',3);
insert into appearance values
    ('Dead Again',1991,'Gray Baker',3);
insert into appearance values
    ('Dead Again',1991,'Margaret Strauss',4);
insert into appearance values
    ('Dead Again',1991,'Mike Church',5);
insert into appearance values
    ('Dead Again',1991,'Margaret Strauss',5);
insert into appearance values
    ('Dead Again',1991,'Gray Baker',6);
insert into appearance values
    ('Dead Again',1991,'Mike Church',7);
insert into appearance values
    ('Dead Again',1991,'Margaret Strauss',7);
insert into appearance values
    ('Dead Again',1991,'Gray Baker',8);
insert into appearance values
    ('Jurassic Park',1993,'Alan Grant',1);
insert into appearance values
    ('Jurassic Park',1993,'Ellie Sattler',1);
insert into appearance values
    ('Jurassic Park',1993,'Ian Malcolm',2);
insert into appearance values
    ('Jurassic Park',1993,'Ellie Sattler',3);
insert into appearance values
    ('Jurassic Park',1993,'Alan Grant',4);
insert into appearance values
    ('Jurassic Park',1993,'Ian Malcolm',5);
insert into appearance values
    ('Jurassic Park',1993,'John Parker Hammond',5);
insert into appearance values
    ('Jurassic Park',1993,'Ian Malcolm',6);
insert into appearance values
    ('Jurassic Park',1993,'Alan Grant',7);
insert into appearance values
    ('Jurassic Park',1993,'John Parker Hammond',8);
insert into appearance values
    ('Jurassic Park',1993,'Ellie Sattler',8);
insert into appearance values
    ('Jurassic Park',1993,'John Parker Hammond',9);
insert into appearance values
    ('Clueless',1995,'Cher Horowitz',1);
insert into appearance values
    ('Clueless',1995,'Dionne',2);
insert into appearance values
    ('Clueless',1995,'Tai Fraiser',2);
insert into appearance values
    ('Clueless',1995,'Cher Horowitz',3);
insert into appearance values
    ('Clueless',1995,'Cher Horowitz',4);
insert into appearance values
    ('Clueless',1995,'Dionne',4);
insert into appearance values
    ('Clueless',1995,'Tai Fraiser',4);
insert into appearance values
    ('Clueless',1995,'Dionne',5);
insert into appearance values
    ('Clueless',1995,'Tai Fraiser',5);
insert into appearance values
    ('Clueless',1995,'Cher Horowitz',6);
insert into appearance values
    ('Clueless',1995,'Dionne',7);
insert into appearance values
    ('Clueless',1995,'Tai Fraiser',7);
insert into appearance values
    ('Shadowlands',1993,'Lewis',1);
insert into appearance values
    ('Shadowlands',1993,'Joy Gresham',1);
insert into appearance values
    ('Shadowlands',1993,'Lewis',2);
insert into appearance values
    ('Shadowlands',1993,'Arnold Dopliss',2);
insert into appearance values
    ('Shadowlands',1993,'Joy Gresham',3);
insert into appearance values
    ('Shadowlands',1993,'Lewis',4);
insert into appearance values
    ('Shadowlands',1993,'Arnold Dopliss',5);
insert into appearance values
    ('Shadowlands',1993,'Lewis',6);
insert into appearance values
    ('Shadowlands',1993,'Arnold Dopliss',6);
insert into appearance values
    ('Shadowlands',1993,'Joy Gresham',7);
insert into appearance values
    ('Shadowlands',1993,'Arnold Dopliss',7);
insert into appearance values
    ('Amateur',1994,'Isabelle',1);
insert into appearance values
    ('Amateur',1994,'Thomas Ludens',1);
insert into appearance values
    ('Amateur',1994,'Sofia Ludens',1);
insert into appearance values
    ('Amateur',1994,'Isabelle',2);
insert into appearance values
    ('Amateur',1994,'Thomas Ludens',2);
insert into appearance values
    ('Amateur',1994,'Thomas Ludens',3);
insert into appearance values
    ('Amateur',1994,'Sofia Ludens',3);
insert into appearance values
    ('Amateur',1994,'Isabelle',4);
insert into appearance values
    ('Amateur',1994,'Sofia Ludens',4);
insert into appearance values
    ('Amateur',1994,'Isabelle',5);
insert into appearance values
    ('Amateur',1994,'Thomas Ludens',5);
insert into appearance values
    ('GoodFellas',1990,'James',1);
insert into appearance values
    ('GoodFellas',1990,'Henry Hill',2);
insert into appearance values
    ('GoodFellas',1990,'Tommy DeVito',2);
insert into appearance values
    ('GoodFellas',1990,'James',3);
insert into appearance values
    ('GoodFellas',1990,'Henry Hill',3);
insert into appearance values
    ('GoodFellas',1990,'Tommy DeVito',4);
insert into appearance values
    ('GoodFellas',1990,'James',5);
insert into appearance values
    ('GoodFellas',1990,'Henry Hill',6);
insert into appearance values
    ('GoodFellas',1990,'James',7);
insert into appearance values
    ('GoodFellas',1990,'Tommy DeVito',8);
insert into appearance values
    ('GoodFellas',1990,'James',9);
insert into appearance values
    ('GoodFellas',1990,'Tommy DeVito',9);
insert into appearance values
    ('GoodFellas',1990,'James',10);
insert into appearance values
    ('GoodFellas',1990,'Henry Hill',11);
insert into appearance values
    ('Little Women',1994,'Josephine',1);
insert into appearance values
    ('Little Women',1994,'Friedrich',2);
insert into appearance values
    ('Little Women',1994,'Josephine',3);
insert into appearance values
    ('Little Women',1994,'Margaret',3);
insert into appearance values
    ('Little Women',1994,'Josephine',4);
insert into appearance values
    ('Little Women',1994,'Older Amy March',4);
insert into appearance values
    ('Little Women',1994,'Margaret',5);
insert into appearance values
    ('Little Women',1994,'Josephine',6);
insert into appearance values
    ('Little Women',1994,'Friedrich',6);
insert into appearance values
    ('Little Women',1994,'Older Amy March',7);
insert into appearance values
    ('Little Women',1994,'Josephine',8);
insert into appearance values
    ('Little Women',1994,'Older Amy March',8);
insert into appearance values
    ('While You Were Sleeping',1995,'Narrator',1);
insert into appearance values
    ('While You Were Sleeping',1995,'Jack Callaghan',1);
insert into appearance values
    ('While You Were Sleeping',1995,'Narrator',2);
insert into appearance values
    ('While You Were Sleeping',1995,'Saul',3);
insert into appearance values
    ('While You Were Sleeping',1995,'Jack Callaghan',4);
insert into appearance values
    ('While You Were Sleeping',1995,'Saul',4);
insert into appearance values
    ('While You Were Sleeping',1995,'Narrator',5);
insert into appearance values
    ('While You Were Sleeping',1995,'Saul',6);
insert into appearance values
    ('While You Were Sleeping',1995,'Narrator',7);
insert into appearance values
    ('While You Were Sleeping',1995,'Saul',7);
insert into appearance values
    ('While You Were Sleeping',1995,'Jack Callaghan',8);
insert into appearance values
    ('While You Were Sleeping',1995,'Narrator',9);
