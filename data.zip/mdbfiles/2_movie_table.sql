--Table MOVIE 

insert into movie values  
            ('Titanic',1997,'USA',195,'romance');
insert into movie values  
            ('Shakespeare in Love',1998,'UK',122,'romance'); 
insert into movie values  
            ('The Cider House Rules',1999,'USA',125,'drama'); 
insert into movie values  
            ('Gandhi',1982,'India',188,'drama'); 
insert into movie values  
            ('American Beauty',1999,'USA',121,'drama');
insert into movie values  
            ('Affliction',1997,'USA',113,'drama'); 
insert into movie values  
            ('Life is Beautiful',1997,'Italy',118,'comedy'); 
insert into movie values  
            ('Boys Dont Cry',1999,'USA',118,'drama'); 
insert into movie values  
            ('Saving Private Ryan',1998,'USA',170,'action'); 
insert into movie values  
            ('The Birds',1963,'USA',119,'horror');
insert into movie values  
            ('The Matrix',1999,'USA',136,'action');
insert into movie values  
            ('Toy Story',1995,'USA',81,'animation');
insert into movie values  
            ('You have Got Mail',1998,'USA',119,'comedy');
insert into movie values  
            ('Proof of Life',2000,'USA',135,'drama');
insert into movie values  
            ('Hanging Up',2000,'USA',94,'comedy');
insert into movie values  
            ('The Price of Milk',2000,'New Zealand',87,'romance');
insert into movie values  
            ('The Footstep Man',1992,'New Zealand',89,'drama');
insert into movie values  
            ('Topless Women Talk About Their Lives',1997,'New Zealand',87,'drama');
insert into movie values  
            ('The Piano',1993,'New Zealand',121,'romance');
insert into movie values  
            ('Mad Max',1979,'Australia',88,'action');
insert into movie values  
            ('Strictly Ballroom',1992,'Australia',94,'comedy');
insert into movie values  
            ('My Mother Frank',2000,'Australia',95,'comedy');
insert into movie values  
            ('American Psycho',2000,'Canada',101,'horror');
insert into movie values  
            ('Scream 2',1997,'USA',116,'horror');
insert into movie values  
            ('Scream 3',2000,'USA',116,'horror');
insert into movie values  
            ('Traffic',2000,'Germany',147,'crime');
insert into movie values  
            ('Psycho',1960,'USA',109,'horror');
insert into movie values  
            ('I Know What You Did Last Summer',1997,'USA',100,'horror');
insert into movie values  
            ('Cruel Intentions',1999,'USA',95,'romance');
insert into movie values  
            ('Wild Things',1998,'USA',108,'crime');
insert into movie values  
            ('Alien',1979,'UK',117,'horror');
insert into movie values  
            ('Aliens',1986,'USA',154,'action');
insert into movie values  
            ('Alien 3',1992,'USA',115,'action');
insert into movie values  
            ('Alien: Resurrection',1997,'USA',109,'action');
insert into movie values  
            ('Gladiator',2000,'UK',154,'drama');
insert into movie values  
            ('The World Is Not Enough',1999,'UK',127,'action');
insert into movie values  
            ('Heat',1995,'USA',171,'action');
insert into movie values  
            ('American History X',1998,'USA',119,'drama');
insert into movie values  
            ('Fight Club',1999,'Germany',139,'drama');
insert into movie values  
            ('Out of Sight',1998,'USA',122,'comedy');
insert into movie values  
            ('Entrapment',1999,'Germany',113,'action');
insert into movie values  
            ('The Insider',1999,'USA',157,'drama');
insert into movie values  
            ('The Blair Witch Project',1999,'USA',86,'drama');
insert into movie values  
            ('Lethal Weapon 4',1998,'USA',127,'crime');
insert into movie values  
            ('The Fifth Element',1997,'USA',126,'action');
insert into movie values  
            ('The Sixth Sense',1999,'USA',106,'thriller');
insert into movie values  
            ('Unbreakable',2000,'USA',106,'thriller');
insert into movie values  
            ('Armageddon',1998,'USA',153,'action');
insert into movie values  
            ('The Kid',2000,'USA',104,'comedy');
insert into movie values  
            ('Twelve Monkeys',1995,'USA',129,'thriller');
insert into movie values
       ('Rear Window',1954,'USA',112,'thriller');
insert into movie values  
            ('Bullets Over Broadway',1994,'USA',98,'comedy');
insert into movie values  
            ('Tombstone',1993,'USA',130,'western'); 
insert into movie values  
            ('Alice',1990,'USA',106,'romance'); 
insert into movie values  
            ('Mermaids',1990,'USA',110,'comedy'); 
insert into movie values  
            ('Exotica',1994,'Canada',103,'drama');
insert into movie values  
            ('Red Rock West',1992,'USA',94,'thriller'); 
insert into movie values  
            ('Chaplin',1992,'USA',145,'drama'); 
insert into movie values  
            ('Fearless',1993,'USA',122,'drama'); 
insert into movie values  
            ('Threesome',1994,'USA',93,'comedy'); 
insert into movie values  
            ('Jungle Fever',1991,'USA',132,'romance');
insert into movie values  
            ('Internal Affairs',1990,'USA',115,'thriller');
insert into movie values  
            ('Single White Female',1992,'USA',103,'thriller');
insert into movie values  
            ('Trust',1990,'USA',90,'comedy');
insert into movie values  
            ('Ju Dou',1990,'China',95,'drama');
insert into movie values  
            ('Dahong Denglong Gaogao Gua',1991,'China',125,'drama');
insert into movie values  
            ('Cyrano de Bergerac',1990,'France',135,'action');
insert into movie values  
            ('Manhattan Murder Mystery',1993,'USA',104,'comedy');
insert into movie values  
            ('El Mariachi',1992,'Mexico',81,'thriller');
insert into movie values  
            ('Once Were Warriors',1994,'New Zealand',99,'drama');
insert into movie values  
            ('Priest',1994,'UK',103,'comedy');
insert into movie values  
            ('Pump Up the Volum',1990,'USA',105,'drama');
insert into movie values  
            ('Benny and Joon',1993,'USA',98,'comedy');
insert into movie values  
            ('Six Degrees of Separation',1993,'USA',101,'drama');
insert into movie values  
            ('Bawang Bie Ji',1993,'China',157,'drama');
insert into movie values  
            ('In the Line of Fire',1993,'USA',110,'action');
insert into movie values  
            ('Heavenly Creatures',1994,'New Zealand',109,'thriller');
insert into movie values  
            ('Hoop Dreams',1994,'USA',175,'documentary');
insert into movie values  
            ('Seven',1995,'USA',123,'thriller');
insert into movie values  
            ('Shallow Grave',1994,'UK',93,'thriller');
insert into movie values  
            ('French Kiss',1995,'USA',111,'comedy');
insert into movie values  
            ('Braindead',1992,'New Zealand',104,'comedy');
insert into movie values  
            ('Clerks',1994,'USA',92,'comedy');
insert into movie values  
            ('Apollo 13',1995,'USA',140,'action');
insert into movie values  
            ('Reservoir Dogs',1992,'USA',100,'thriller');
insert into movie values  
            ('Pulp Fiction',1994,'USA',154,'crime');
insert into movie values  
            ('Yinshi Nan Nu',1994,'Taiwan',123,'comedy');
insert into movie values  
            ('Short Cuts',1993,'USA',187,'drama');
insert into movie values  
            ('Legends of the Fall',1994,'USA',133,'romance');
insert into movie values  
            ('Natural Born Killers',1994,'USA',118,'violence');
insert into movie values  
            ('In the Mouth of Madness',1995,'USA',95,'horror');
insert into movie values  
            ('Forrest Gump',1994,'USA',142,'comedy');
insert into movie values  
            ('Malcolm X',1992,'USA',194,'drama');
insert into movie values  
            ('Dead Again',1991,'USA',107,'thriller');
insert into movie values  
            ('Jurassic Park',1993,'USA',127,'action');
insert into movie values  
            ('Clueless',1995,'USA',97,'comedy');
insert into movie values  
            ('Shadowlands',1993,'UK',131,'drama');
insert into movie values  
            ('Amateur',1994,'USA',105,'thriller');
insert into movie values  
            ('GoodFellas',1990,'USA',146,'violence');
insert into movie values  
            ('Little Women',1994,'USA',115,'drama');
insert into movie values  
            ('While You Were Sleeping',1995,'USA',103,'romance');