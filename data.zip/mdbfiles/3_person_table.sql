-- Table PERSON

insert into person values
    ('00001001','James','Stewart',1908);
insert into person values
    ('00001002','Grace','Kelly',1929);
insert into person values
    ('00001003','Raymond','Burr',1917);
insert into person values
    ('00001004','John Michael','Hayes',1919);
insert into person values  
            ('00000982','Delia','Ephron',1943);
insert into person values  
            ('00000983','Lisa','Kudrow',1963);
insert into person values  
            ('00000961','Taylor','Hackford',1945);
insert into person values  
            ('00000962','Tony','Gilroy (I)',1962);
insert into person values  
            ('00000963','David','Morse',1953);
insert into person values  
            ('00000941','John','Lasseter',1957);
insert into person values  
            ('00000942','Tim','Allen',1953);
insert into person values  
            ('00000943','Annie','Potts',1952);
insert into person values  
            ('00000921','Terry','Gilliam',1940);
insert into person values  
            ('00000922','Chris','Marker',1921);
insert into person values  
            ('00000923','Joseph','Melito',1932);
insert into person values  
            ('00000902','Audrey','Wells',1961);
insert into person values  
            ('00000903','Spencer','Breslin',1992);
insert into person values  
            ('00000904','Emily','Mortimer',1971);
insert into person values  
            ('00000881','Michael','Bay',1965);
insert into person values  
            ('00000882','Robert','Roy Pool',1957);
insert into person values  
            ('00000883','Billy','Bob Thornton',1955);
insert into person values  
            ('00000884','Liv','Tyler',1977);
insert into person values  
            ('00000862','Spencer','Clark',1987);
insert into person values  
            ('00000841','M. Night','Shyamalan',1970);
insert into person values  
            ('00000842','Haley','Joel Osment',1988);
insert into person values  
            ('00000843','Toni','Collette',1972);
insert into person values  
            ('00000821','Luc','Besson',1959);
insert into person values  
            ('00000822','Bruce','Willis',1955);
insert into person values  
            ('00000823','Gary','Oldman',1958);
insert into person values  
            ('00000824','Milla','Jovovich',1975);
insert into person values  
            ('00000801','Richard','Donner',1930);
insert into person values  
            ('00000802','Jonathan','Lemkin',1948);
insert into person values  
            ('00000803','Danny','Glover',1946);
insert into person values  
            ('00000781','Daniel','Myrick',1964);
insert into person values  
            ('00000782','Heather','Donahue',1974);
insert into person values  
            ('00000783','Joshua','Leonard',1975);
insert into person values  
            ('00000784','Michael','C. Williams',1973);
insert into person values  
            ('00000761','Marie','Brenner',1963);
insert into person values  
            ('00000762','Diane','Venora',1952);
insert into person values  
            ('00000741','Jon','Amiel',1948);
insert into person values  
            ('00000742','Ronald','Bass',1943);
insert into person values  
            ('00000743','Sean','Connery',1930);
insert into person values  
            ('00000744','Ving','Rhames',1961);
insert into person values  
            ('00000721','Elmore','Leonard',1925);
insert into person values  
            ('00000722','George','Clooney',1961);
insert into person values  
            ('00000723','Jim','Robinson (I)',1947);
insert into person values  
            ('00000724','Jennifer','Lopez',1970);
insert into person values  
            ('00000701','Chuck','Palahniuk',1955);
insert into person values  
            ('00000703','Meat','Loaf',1951);
insert into person values  
            ('00000681','Tony','Kaye (I)',1968);
insert into person values  
            ('00000682','David ','McKenna',1968);
insert into person values  
            ('00000683','Edward','Norton',1969);
insert into person values  
            ('00000684','Edward','Furlong',1977);
insert into person values  
            ('00000685','Beverly','DAngelo',1969);
insert into person values  
            ('00000661','Michael','Mann',1943);
insert into person values  
            ('00000662','Al','Pacino',1940);
insert into person values  
            ('00000663','Robert','De Niro',1943);
insert into person values  
            ('00000641','Michael','Apted',1941);
insert into person values  
            ('00000642','Neal','Purvis',1950);
insert into person values  
            ('00000643','Pierce','Brosnan',1953);
insert into person values  
            ('00000644','Sophie','Marceau',1966);
insert into person values  
            ('00000645','Denise','Richards',1972);
insert into person values  
            ('00000621','David','H. Franzoni',1967);
insert into person values  
            ('00000622','Russell','Crowe',1964);
insert into person values  
            ('00000623','Joaquin','Phoenix',1974);
insert into person values  
            ('00000624','Connie','Nielsen',1965);
insert into person values  
            ('00000601','Jean-Pierre','Jeunet',1955);
insert into person values  
            ('00000602','Joss','Whedon',1964);
insert into person values  
            ('00000604','Dominique','Pinon',1955);
insert into person values  
            ('00000582','Vincent','Ward',1956);
insert into person values  
            ('00000583','Charles','Dutton',1951);
insert into person values  
            ('00000584','Charles','Dance',1946);
insert into person values  
            ('00000561','Carrie','Henn',1976);
insert into person values  
            ('00000562','Don','Sharpe',1968);
insert into person values  
            ('00000563','Suzanne','M. Benson',1959);
insert into person values  
            ('00000564','Brian','Johnson (I)',1970);
insert into person values  
            ('00000541','Ridley','Scott',1937);
insert into person values  
            ('00000542','Dan','OBannon',1946);
insert into person values  
            ('00000543','Tom','Skerritt',1933);
insert into person values  
            ('00000544','Sigourney','Weaver',1949);
insert into person values  
            ('00000545','Derrick','Leather',1960);
insert into person values  
            ('00000546','Michael','Seymour (I)',1958);
insert into person values  
            ('00000547','Nick','Allder',1963);
insert into person values  
            ('00000521','John','McNaughton',1950);
insert into person values  
            ('00000522','Stephen ','Peters',1947);
insert into person values  
            ('00000524','Matt','Dillon',1964);
insert into person values  
            ('00000501','Roger','Kumble',1966);
insert into person values  
            ('00000502','Choderlos','de Laclos',1741);
insert into person values  
            ('00000503','Reese','Witherspoon',1976);
insert into person values  
            ('00000504','Selma','Blair',1972);
insert into person values  
            ('00000481','Jim','Gillespie (I)',1968);
insert into person values  
            ('00000482','Lois','Duncan',1972);
insert into person values  
            ('00000483','Jennifer','Love Hewitt',1979);
insert into person values  
            ('00000484','Ryan','Phillippe',1974);
insert into person values  
            ('00000485','Sarah','Michelle Gellar',1977);
insert into person values  
            ('00000461','Robert','Bloch',1917);
insert into person values  
            ('00000462','Anthony','Perkins',1932);
insert into person values  
            ('00000463','Vera','Miles',1929);
insert into person values  
            ('00000464','Janet','Leigh',1927);
insert into person values
            ('00000465','John','Gavin',1928);
insert into person values
            ('00000466','Paul','Jasmin',1921);
insert into person values  
            ('00000441','Steven','Soderbergh',1963);
insert into person values  
            ('00000442','Stephen','Gaghan',1956);
insert into person values  
            ('00000443','Michael','Douglas',1944);
insert into person values  
            ('00000444','Benicio','Del Toro',1967);
insert into person values  
            ('00000445','Catherine','Zeta-Jones',1969);
insert into person values  
            ('00000446','Stephen','Bauer',1956);
insert into person values  
            ('00000447','Luis','Guzman',1967);
insert into person values  
            ('00000448','Amy','Irving',1953);
insert into person values  
            ('00000449','Erika','Christensen',1982);
insert into person values  
            ('00000450','Don','Cheadle',1964);
insert into person values  
            ('00000451','Jacob','Vargas',1963);
insert into person values  
            ('00000452','Clifton','Collins',1971);
insert into person values  
            ('00000421','Liev','Schreiber',1967);
insert into person values  
            ('00000422','Beth','Toussaint',1962);
insert into person values  
            ('00000423','Roger','Jackson',1965);
insert into person values  
            ('00000424','Kelly','Rutherford',1968);
insert into person values  
            ('00000401','Wes','Craven',1939);
insert into person values  
            ('00000402','Kevin','Williamson',1965);
insert into person values  
            ('00000403','David','Arquette',1971);
insert into person values  
            ('00000404','Neve','Campbell',1973);
insert into person values  
            ('00000405','Courteney','Cox',1964);
insert into person values  
            ('00000381','Mary','Harron (I)',1966);
insert into person values  
            ('00000382','Bret','Easton Ellis',1964);
insert into person values  
            ('00000383','Christian','Bale',1974);
insert into person values  
            ('00000384','Willem','Dafoe',1955);
insert into person values  
            ('00000385','Jared','Leto',1971);
insert into person values  
            ('00000361','Mark','Lamprell',1950);
insert into person values  
            ('00000362','Nicholas','Bishop',1974);
insert into person values  
            ('00000363','Rose','Byrne',1953);
insert into person values  
            ('00000364','Sinead','Cusack',1948);
insert into person values  
            ('00000341','Baz','Luhrmann',1942);
insert into person values  
            ('00000342','Craig','Pearce',1948);
insert into person values  
            ('00000343','Paul','Mercurio',1963);
insert into person values  
            ('00000344','Tara','Morice',1967);
insert into person values  
            ('00000345','Pat','Thompson (II)',1940);
insert into person values  
            ('00000346','Barry','Otto',1965);
insert into person values  
            ('00000347','Jill','Bilcock',1967);
insert into person values  
            ('00000348','Catherine','Martin (I)',1950);
insert into person values  
            ('00000349','Angus','Strathie',1954);
insert into person values  
            ('00000321','George','Miller (II)',1945);
insert into person values  
            ('00000322','James','McCausland',1943);
insert into person values  
            ('00000323','Mel','Gibson',1956);
insert into person values  
            ('00000324','Joanne','Samuel',1951);
insert into person values  
            ('00000325','Brian','May (I)',1934);
insert into person values  
            ('00000001','James','Cameron',1954);
insert into person values  
            ('00000002','Leonardo','DiCaprio',1974);
insert into person values  
            ('00000004','Billy','Zane',1966);
insert into person values  
            ('00000005','Kathy','Bates',1948);
insert into person values  
            ('00000006','Michael','Ford (I)',1966);
insert into person values  
            ('00000007','Russell','Carpenter',1971);
insert into person values  
            ('00000008','Deborah','Lynn Scott',1968);
insert into person values  
            ('00000009','Thomas','L.Fisher',1956);
insert into person values  
            ('00000010','Tom','Bellfort',1964);
insert into person values  
            ('00000011','Conrad','Buff IV',1956);
insert into person values  
            ('00000012','James','Horner',1953);
insert into person values  
            ('00000013','Will','Jennings (II)',1961);
insert into person values  
            ('00000021','John','Madden',1949);
insert into person values  
            ('00000022','Marc','Norman',1952);
insert into person values  
            ('00000023','Geoffrey','Rush',1951);
insert into person values  
            ('00000025','Steve','ODonnell',1956);
insert into person values  
            ('00000026','Judi','Dench',1934);
insert into person values  
            ('00000027','Sandy','Powell',1940);
insert into person values  
            ('00000041','Lasse','Hallstrom',1946);
insert into person values  
            ('00000042','John','Irving',1942);
insert into person values  
            ('00000043','Kate','Nelligan',1950);
insert into person values  
            ('00000044','Tobey','Maguire',1975);
insert into person values  
            ('00000045','Charlize','Theron',1975);
insert into person values  
            ('00000046','Delroy','Lindo',1952);
insert into person values  
            ('00000047','Michael','Caine',1958);
insert into person values  
            ('00000062','John','Briley',1925);
insert into person values  
            ('00000063','Ben','Kingsley',1943);
insert into person values  
            ('00000064','Candice','Bergen',1946);
insert into person values  
            ('00000065','Roshan','Seth',1942);
insert into person values  
            ('00000066','Edward','Fox',1937);
insert into person values  
            ('00000081','Sam','Mendes',1965);
insert into person values  
            ('00000082','Alan','Ball',1957);
insert into person values  
            ('00000083','Kevin','Spacey',1959);
insert into person values  
            ('00000084','Annette','Bening',1958);
insert into person values  
            ('00000085','Thora','Birch',1982);
insert into person values  
            ('00000086','Wes','Bentley',1978);
insert into person values  
            ('00000101','Paul','Schrader',1946);
insert into person values  
            ('00000102','Russell','Banks',1940);
insert into person values  
            ('00000103','Nick','Nolte',1941);
insert into person values  
            ('00000104','Brigid','Tierney',1948);
insert into person values  
            ('00000105','Holmes','Osborne',1950);
insert into person values  
            ('00000106','Jim','True',1945);
insert into person values  
            ('00000107','James','Coburn',1928);
insert into person values  
            ('00000121','Roberto','Benigini',1952);
insert into person values  
            ('00000122','Vincenzo','Cerami',1940);
insert into person values  
            ('00000123','Nicoletta','Braschi',1960);
insert into person values  
            ('00000141','Kimberly','Peirce',1967);
insert into person values  
            ('00000142','Andy','Bienen',1965);
insert into person values  
            ('00000143','Hilary','Swank',1974);
insert into person values  
            ('00000144','Chloe','Sevigny',1974);
insert into person values  
            ('00000145','Peter','Sarsgaard',1972);
insert into person values  
            ('00000146','Brendan','Sexton III',1980);
insert into person values  
            ('00000162','Robert','Rodat',1953);
insert into person values  
            ('00000164','Tom','Sizemore',1964);
insert into person values  
            ('00000165','Edwards','Burns',1968);
insert into person values  
            ('00000166','Barry','Pepper',1970);
insert into person values  
            ('00000181','Alfred','Hitchcock',1932);
insert into person values  
            ('00000182','Daphne','Du Maurier',1940);
insert into person values  
            ('00000183','Evan','Hunter',1937);
insert into person values  
            ('00000184','Rod','Taylor',1935);
insert into person values  
            ('00000185','Jessica','Tandy',1941);
insert into person values  
            ('00000186','Suzanne','Pleshette',1938);
insert into person values
            ('00000187','Tippi','Hedren',1931);
insert into person values  
            ('00000201','Andy','Wachowski',1965);
insert into person values  
            ('00000202','Larry','Wachowski',1968);
insert into person values  
            ('00000203','Keanu','Reeves',1972);
insert into person values  
            ('00000204','Laurence','Fishburne',1970);
insert into person values  
            ('00000205','John','Gaeta',1962);
insert into person values  
            ('00000206','Janek','Sirrs',1957);
insert into person values  
            ('00000207','Steve','Courtley',1961);
insert into person values  
            ('00000208','Jon','Thum',1956);
insert into person values  
            ('00000209','Dane','A.davis',1966);
insert into person values  
            ('00000222','Nora','Ephron',1941);
insert into person values  
            ('00000223','Parker','Posey',1968);
insert into person values  
            ('00000241','Harry','Sinclair (II)',1965);
insert into person values  
            ('00000242','Danielle','Cormack',1959);
insert into person values  
            ('00000243','Karl','Urban',1972);
insert into person values  
            ('00000244','Willa','ONeill',1970);
insert into person values  
            ('00000261','Leon','Narbey',1958);
insert into person values  
            ('00000262','Stephen','Grives',1971);
insert into person values  
            ('00000263','Jennifer','Ward-Lealand',1966);
insert into person values  
            ('00000264','Michael','Hurst (I)',1957);
insert into person values  
            ('00000281','Joel','Tobeck',1971);
insert into person values  
            ('00000282','Ian','Hughes (I)',1968);
insert into person values  
            ('00000301','Jane','Campion',1954);
insert into person values  
            ('00000302','Holly','Hunter',1958);
insert into person values  
            ('00000304','Anna','Paquin',1982);
insert into person values  
            ('00000306','Janet','Patterson',1967);
insert into person values  
            ('00000307','Andrew','McAlpine',1962);
insert into person values
    ('00001005','Woody','Allen',1935);
insert into person values
    ('00001006','John','Cusack',1966);
insert into person values
    ('00001007','Jack','Warden',1920);
insert into person values
    ('00001008','Tony','Sirico',1942);
insert into person values
    ('00001009','Robert','Greenhut',1943);
insert into person values
    ('00001010','Carlo','DiPalma',1925);
insert into person values
    ('00001011','Susan E.','Morse',1930);
insert into person values
    ('00001012','Juliet','Taylor',1967);
insert into person values
    ('00001013','Jeffrey','Kurland',1958);
insert into person values
    ('00001014','George P.','Cosmatos',1941);
insert into person values
    ('00001015','Kevin','Jarre',1938);
insert into person values
    ('00001016','Kurt','Russell',1951);
insert into person values
    ('00001017','Val','Kilmer',1959);
insert into person values
    ('00001018','Sam','Elliott',1944);
insert into person values
    ('00001019','Sean','Daniel',1951);
insert into person values
    ('00001020','William A.','Fraker',1923);
insert into person values
    ('00001021','Harvey','Rosenstock',1935);
insert into person values
    ('00001022','Lora','Kennedy',1940);
insert into person values
    ('00001023','Joseph A.','Porro',1943);
insert into person values
    ('00001024','Joe','Mantegna',1947);
insert into person values
    ('00001025','Mia','Farrow',1945);
insert into person values
    ('00001026','William','Hurt',1950);
insert into person values
    ('00001027','Richard','Benjamin',1938);
insert into person values
    ('00001028','Patty','Dann',1942);
insert into person values
    ('00001029','Cherilyn','LaPierre',1946);
insert into person values
    ('00001030','Bob','Hoskins',1942);
insert into person values
    ('00001031','Winona','Ryder',1971);
insert into person values
    ('00001032','Lauren','Lloyd',1941);
insert into person values
    ('00001033','Howard','Atherton',1938);
insert into person values
    ('00001034','Jacqueline','Cambas',1952);
insert into person values
    ('00001035','Margery','Simkin',1947);
insert into person values
    ('00001036','Marit','Allen',1954);
insert into person values
    ('00001037','Atom','Egoyan',1960);
insert into person values
    ('00001038','David','Hemblen',1958);
insert into person values
    ('00001039','Don','Mckellar',1963);
insert into person values
    ('00001040','Mia','Kirshner',1976);
insert into person values
    ('00001041','Paul','Sarossy',1963);
insert into person values
    ('00001042','Susan','Shipton',1959);
insert into person values
    ('00001043','Linda','Muir',1960);
insert into person values
    ('00001044','John','Dahl',1956);
insert into person values
    ('00001045','Nicolas','Cage',1964);
insert into person values
    ('00001046','Craig','Reay',1967);
insert into person values
    ('00001047','Steve','Golin',1958);
insert into person values
    ('00001048','Marc','Reshovsky',1965);
insert into person values
    ('00001049','Scott','Chestnut',1959);
insert into person values
    ('00001050','Terry','Dresbach',1964);
insert into person values
    ('00001051','Richard','Attenborough',1923);
insert into person values
    ('00001052','Charles','Chaplin',1889);
insert into person values
    ('00001053','Robert','Downey Jr.',1965);
insert into person values
    ('00001054','Geraldine','Chaplin',1944);
insert into person values
    ('00001055','Paul','Rhys',1963);
insert into person values
    ('00001056','Sven','Nykvist',1922);
insert into person values
    ('00001057','Anne V.','Coates',1925);
insert into person values
    ('00001058','Mike','Fenton',1947);
insert into person values
    ('00001059','Ellen','Mirojnick',1949);
insert into person values
    ('00001060','Peter','Weir',1944);
insert into person values
    ('00001061','Rafael','Yglesias',1954);
insert into person values
    ('00001062','Jeff','Bridges',1949);
insert into person values
    ('00001063','Isabella','Rossellini',1952);
insert into person values
    ('00001064','Rosie','Perez',1964);
insert into person values
    ('00001065','Mark','Rosenberg',1948);
insert into person values
    ('00001066','Allen','Daviau',1953);
insert into person values
    ('00001067','Bill','Anderson',1962);
insert into person values
    ('00001068','Howard','Feuer',1965);
insert into person values
    ('00001069','Marilyn','Matthews',1955);
insert into person values
    ('00001070','Andrew','Fleming',1946);
insert into person values
    ('00001071','Lara','Boyle',1970);
insert into person values
    ('00001072','Stephen','Baldwin',1966);
insert into person values
    ('00001073','Josh','Charles',1971);
insert into person values
    ('00001074','Brad','Krevoy',1967);
insert into person values
    ('00001075','Alexander','Gruszynski',1954);
insert into person values
    ('00001076','Bill','Carruth',1949);
insert into person values
    ('00001077','Ed','Mitchell',1955);
insert into person values
    ('00001078','Deborah','Everton',1962);
insert into person values
    ('00001079','Spike','Lee',1957);
insert into person values
    ('00001080','Wesley','Snipes',1962);
insert into person values
    ('00001081','Annabella','Sciorra',1964);
insert into person values
    ('00001082','Ernest R.','Dickerson',1952);
insert into person values
    ('00001083','Samuel D.','Pollard',1963);
insert into person values
    ('00001084','Robi','Reed',1954);
insert into person values
    ('00001085','Ruth E.','Carter',1968);
insert into person values
    ('00001086','Mike','Figgis',1948);
insert into person values
    ('00001087','Henry','Bean',1943);
insert into person values
    ('00001088','Richard','Gere',1949);
insert into person values
    ('00001089','Andy','Carcia',1956);
insert into person values
    ('00001090','Nancy','Travis',1961);
insert into person values
    ('00001091','Frank','Mancuso',1958);
insert into person values
    ('00001092','John','Alonzo',1934);
insert into person values
    ('00001093','Robert','Estrin',1942);
insert into person values
    ('00001094','Carrie','Frazier',1947);
insert into person values
    ('00001095','Rudy','Dillon',1950);
insert into person values
    ('00001096','Barbet','Schroeder',1941);
insert into person values
    ('00001097','John','Lutz',1948);
insert into person values
    ('00001098','Bridget','Fonda',1964);
insert into person values
    ('00001099','Jennifer','Leigh',1962);
insert into person values
    ('00001100','Steven','Weber',1961);
insert into person values
    ('00001101','Luciano','Tovoli',1965);
insert into person values
    ('00001102','Lee','Percy',1971);
insert into person values
    ('00001103','Milena','Canonero',1965);
insert into person values
    ('00001104','Hal','Hartley',1959);
insert into person values
    ('00001105','Adrienne','Shelly',1966);
insert into person values
    ('00001106','Martin','Donovan',1957);
insert into person values
    ('00001107','Michael','Spiller',1961);
insert into person values
    ('00001108','Nick','Gomez',1963);
insert into person values
    ('00001109','Claudia','Brown',1962);
insert into person values
    ('00001110','Yimou','Zhang',1951);
insert into person values
    ('00001111','Heng','Liu',1964);
insert into person values
    ('00001112','Li','Gong',1965);
insert into person values
    ('00001113','Baotian','Li',1950);
insert into person values
    ('00001114','Hu','Jian',1962);
insert into person values
    ('00001115','Changwei','Gu',1965);
insert into person values
    ('00001116','Yuan','Du',1955);
insert into person values
    ('00001117','Zhi-an','Zhang',1963);
insert into person values
    ('00001118','Su','Tong',1957);
insert into person values
    ('00001119','Jingwu','Ma',1947);
insert into person values
    ('00001120','Caifei','He',1965);
insert into person values
    ('00001121','Fu-Sheng','Chiu',1956);
insert into person values
    ('00001122','Zhao','Fei',1952);
insert into person values
    ('00001123','Yuan','Du',1967);
insert into person values
    ('00001124','Jean-Paul','Rappeneau',1932);
insert into person values
    ('00001125','Gerard','Depardieu',1948);
insert into person values
    ('00001126','Anne','Brochet',1966);
insert into person values
    ('00001127','Rene','Cleitman',1940);
insert into person values
    ('00001128','Pierre','Lhomme',1930);
insert into person values
    ('00001129','Noelle','Boisson',1942);
insert into person values
    ('00001130','Franca','Squarciapion',1943);
insert into person values
    ('00001131','Diane','Keaton',1946);
insert into person values
    ('00001132','Robert','Rodriguez',1968);
insert into person values
    ('00001133','Carlos','Gallardo',1966);
insert into person values
    ('00001134','Consuelo','Gomez',1958);
insert into person values
    ('00001135','Lee','Tamahori',1950);
insert into person values
    ('00001136','Riwia','Brown',1953);
insert into person values
    ('00001137','Rena','Owen',1960);
insert into person values
    ('00001138','Temuera','Morrison',1961);
insert into person values
    ('00001139','Robin','Scholes',1965);
insert into person values
    ('00001140','Stuart','Dryburgh',1952);
insert into person values
    ('00001141','D.Michael','Horton',1958);
insert into person values
    ('00001142','Don','Selwyn',1960);
insert into person values
    ('00001143','Antonia','Bird',1963);
insert into person values
    ('00001144','Jimmy','McGovern',1949);
insert into person values
    ('00001145','Linus','Roache',1964);
insert into person values
    ('00001146','Tom','Wilkinson',1959);
insert into person values
    ('00001147','George','Faber',1961);
insert into person values
    ('00001148','Fred','Tammes',1963);
insert into person values
    ('00001149','Susan','Spivey',1957);
insert into person values
    ('00001150','Janet','Goddard',1965);
insert into person values
    ('00001151','Allan','Moyle',1947);
insert into person values
    ('00001152','Christian','Slater',1969);
insert into person values
    ('00001153','Samantha','Mathis',1970);
insert into person values
    ('00001154','Sandy','Stern',1968);
insert into person values
    ('00001155','Walt','Lloyd',1972);
insert into person values
    ('00001156','Larry','Bock',1962);
insert into person values
    ('00001157','Judith','Holstra',1964);
insert into person values
    ('00001158','Jeremiah S.','Chechik',1962);
insert into person values
    ('00001159','Barry','Berman',1957);
insert into person values
    ('00001160','Johnny','Depp',1963);
insert into person values
    ('00001161','Mary','Masterson',1966);
insert into person values
    ('00001162','John','Schwartzman',1965);
insert into person values
    ('00001163','Carol','Littleton',1957);
insert into person values
    ('00001164','Risa','Garcia',1956);
insert into person values
    ('00001165','Fred','Schepisi',1939);
insert into person values
    ('00001166','John','Guare',1938);
insert into person values
    ('00001167','Stockard','Channing',1944);
insert into person values
    ('00001168','Will','Smith',1968);
insert into person values
    ('00001169','Donald','Sutherland',1935);
insert into person values
    ('00001170','Ian','Baker',1947);
insert into person values
    ('00001171','Peter','Honess',1951);
insert into person values
    ('00001172','Ellen','Chenoweth',1962);
insert into person values
    ('00001173','Kaige','Chen',1952);
insert into person values
    ('00001174','Lillian','Lee',1954);
insert into person values
    ('00001175','Leslie','Cheung',1956);
insert into person values
    ('00001176','Fengyi','Zhang',1965);
insert into person values
    ('00001177','Feng','Hsu',1948);
insert into person values
    ('00001178','Xiaonan','Pei',1966);
insert into person values
    ('00001179','Wolfgang','Petersen',1941);
insert into person values
    ('00001180','Jeff','Maguire',1948);
insert into person values
    ('00001181','Clint','Eastwood',1930);
insert into person values
    ('00001182','John','Malkovich',1953);
insert into person values
    ('00001183','Rene','Russo',1954);
insert into person values
    ('00001184','John','Bailey',1942);
insert into person values
    ('00001185','Janet','Hirshenson',1950);
insert into person values
    ('00001186','Peter','Jackson',1961);
insert into person values
    ('00001187','Melanie','Lynskey',1977);
insert into person values
    ('00001188','Kate','Winslet',1975);
insert into person values
    ('00001189','Alun','Bollinger',1963);
insert into person values
    ('00001190','Jamie','Selkirk',1966);
insert into person values
    ('00001191','Steve','James',1957);
insert into person values
    ('00001192','William','Gates',1968);
insert into person values
    ('00001193','Arthur','Agee',1956);
insert into person values
    ('00001194','Peter','Gilbert',1963);
insert into person values
    ('00001195','David','Fincher',1962);
insert into person values
    ('00001196','Andrew','Walker',1964);
insert into person values
    ('00001197','Morgan','Freeman',1937);
insert into person values
    ('00001198','Brad','Pitt',1963);
insert into person values
    ('00001199','Darius','Khondji',1956);
insert into person values
    ('00001200','Richard','Francis-Bruce',1948);
insert into person values
    ('00001201','Kerry','Barden',1951);
insert into person values
    ('00001202','Danny','Boyle',1956);
insert into person values
    ('00001203','John','Hodge',1964);
insert into person values
    ('00001204','Kerry','Fox',1966);
insert into person values
    ('00001205','Christopher','Eccleston',1964);
insert into person values
    ('00001206','Ewan','McGregor',1971);
insert into person values
    ('00001207','Andrew','Macdonald',1966);
insert into person values
    ('00001208','Brian','Tufano',1968);
insert into person values
    ('00001209','Masahiro','Hirakubo',1964);
insert into person values
    ('00001210','Lawrence','Kasdan',1949);
insert into person values
    ('00001211','Adam','Brooks',1956);
insert into person values
    ('00001212','Meg','Ryan',1961);
insert into person values
    ('00001213','Kevin','Kline',1947);
insert into person values
    ('00001214','Timothy','Hutton',1960);
insert into person values
    ('00001215','Owen','Roizman',1936);
insert into person values
    ('00001216','Joe','Hutshing',1947);
insert into person values
    ('00001217','Timothy','Balme',1964);
insert into person values
    ('00001218','Diana','Penalver',1967);
insert into person values
    ('00001219','Elizabeth','Moody',1957);
insert into person values
    ('00001220','Murray','Milne',1959);
insert into person values
    ('00001221','Kevin','Smith',1970);
insert into person values
    ('00001222','Marilyn','Ghigliotti',1971);
insert into person values
    ('00001223','Lisa','Spoonhauer',1968);
insert into person values
    ('00001224','David','Klein',1965);
insert into person values
    ('00001225','Ron','Howard',1954);
insert into person values
    ('00001226','Jim','Lovell',1928);
insert into person values
    ('00001227','Tom','Hanks',1956);
insert into person values
    ('00001228','Bill','Paxton',1955);
insert into person values
    ('00001229','Kevin','Bacon',1958);
insert into person values
    ('00001230','Brian','Grazer',1951);
insert into person values
    ('00001231','Dean','Cundey',1945);
insert into person values
    ('00001232','Quentin','Tarantino',1963);
insert into person values
    ('00001233','Harvey','Keitel',1939);
insert into person values
    ('00001234','Tom','Roth',1961);
insert into person values
    ('00001235','Michael','Madsen',1958);
insert into person values
    ('00001236','Sally','Menke',1962);
insert into person values
    ('00001237','Ronnie','Yeskel',1967);
insert into person values
    ('00001238','John','Travolta',1954);
insert into person values
    ('00001239','Samuel','Jackson',1948);
insert into person values
    ('00001240','Lawrence','Bender',1958);
insert into person values
    ('00001241','Ang','Lee',1954);
insert into person values
    ('00001242','Sihung','Lung',1968);
insert into person values
    ('00001243','Yu-Wen','Wang',1969);
insert into person values
    ('00001244','Chien-lien','Wu',1968);
insert into person values
    ('00001245','Kong','Hsu',1956);
insert into person values
    ('00001246','Jong','Lin',1969);
insert into person values
    ('00001247','Tim','Squyres',1962);
insert into person values
    ('00001248','Robert','Altman',1925);
insert into person values
    ('00001249','Andie','MacDowell',1958);
insert into person values
    ('00001250','Bruce','Davison',1946);
insert into person values
    ('00001251','Jack','Lemmon',1925);
insert into person values
    ('00001252','Cary','Brokaw',1951);
insert into person values
    ('00001253','Geraldine','Peroni',1954);
insert into person values
    ('00001254','Edward','Zwick',1952);
insert into person values
    ('00001255','Jim','Harrison',1937);
insert into person values
    ('00001256','Anthony','Hopkins',1937);
insert into person values
    ('00001257','Aidan','Quinn',1959);
insert into person values
    ('00001258','John','Toll',1962);
insert into person values
    ('00001259','Steven','Rosenblum',1963);
insert into person values
    ('00001260','Mary','Colquhoun',1939);
insert into person values
    ('00001261','Oliver','Stone',1946);
insert into person values
    ('00001262','Woody','Harrelson',1961);
insert into person values
    ('00001263','Juliette','Lewis',1973);
insert into person values
    ('00001264','Robert','Richardson',1964);
insert into person values
    ('00001265','Brain','Berdan',1958);
insert into person values
    ('00001266','Richard','Hornung',1950);
insert into person values
    ('00001267','John','Carpenter',1948);
insert into person values
    ('00001268','Michael','Luca',1951);
insert into person values
    ('00001269','Sam','Neil',1947);
insert into person values
    ('00001270','Jurgen','Prochnow',1941);
insert into person values
    ('00001271','Julie','Carmen',1960);
insert into person values
    ('00001272','Gary','Kibbe',1954);
insert into person values
    ('00001273','Edward','Warschilka',1949);
insert into person values
    ('00001274','Robert','Zemeckis',1952);
insert into person values
    ('00001275','Winston','Groom',1944);
insert into person values
    ('00001276','Robin','Wright',1966);
insert into person values
    ('00001277','Gary','Sinise',1955);
insert into person values
    ('00001278','Wendy','Finerman',1953);
insert into person values
    ('00001279','Don','Burgess',1957);
insert into person values
    ('00001280','Ellen','Lewis',1961);
insert into person values
    ('00001281','Denzel','Washington',1954);
insert into person values
    ('00001282','Angela','Bassett',1958);
insert into person values
    ('00001283','Barry','Brown',1952);
insert into person values
    ('00001284','Kenneth','Branagh',1960);
insert into person values
    ('00001285','Scott','Frank',1960);
insert into person values
    ('00001286','Emma','Thompson',1959);
insert into person values
    ('00001287','Lindsay','Doran',1948);
insert into person values
    ('00001288','Matthew','Leonetti',1952);
insert into person values
    ('00001289','Peter','Berger',1955);
insert into person values
    ('00001290','Gail','Levin',1960);
insert into person values
    ('00001291','Steven','Spielberg',1946);
insert into person values
    ('00001292','Michael','Crichton',1942);
insert into person values
    ('00001293','Laura','Dern',1967);
insert into person values
    ('00001294','Jeff','Goldblum',1952);
insert into person values
    ('00001295','Kathleen','Kennedy',1947);
insert into person values
    ('00001296','Michael','Kahn',1924);
insert into person values
    ('00001297','Amy','Heckerling',1954);
insert into person values
    ('00001298','Alicia','Silverston',1976);
insert into person values
    ('00001299','Stacey','Dash',1966);
insert into person values
    ('00001300','Brittany','Murphy',1977);
insert into person values
    ('00001301','Scott','Rudin',1958);
insert into person values
    ('00001302','Bill','Pope',1961);
insert into person values
    ('00001303','Debra','Chiate',1970);
insert into person values
    ('00001304','Marcia','Ross',1969);
insert into person values
    ('00001305','Richard','Attenborough',1923);
insert into person values
    ('00001306','William','Nicholson',1948);
insert into person values
    ('00001307','Debra','Winger',1955);
insert into person values
    ('00001308','Roddy','Maude-Roxby',1930);
insert into person values
    ('00001309','Roger','Pratt',1947);
insert into person values
    ('00001310','Lesley','Walker',1956);
insert into person values
    ('00001311','Lucy','Boulting',1967);
insert into person values
    ('00001312','Isabelle','Huppert',1955);
insert into person values
    ('00001313','Elina','Lowensohn',1966);
insert into person values
    ('00001314','Steven','Hamilton',1968);
insert into person values
    ('00001315','Billy','Hopkins',1965);
insert into person values
    ('00001316','Alexandra','Welker',1959);
insert into person values
    ('00001317','Martin','Scorsese',1942);
insert into person values
    ('00001318','Robert','Niro',1943);
insert into person values
    ('00001319','Ray','Liotta',1955);
insert into person values
    ('00001320','Joe','Pesci',1943);
insert into person values
    ('00001321','Irwin','Winkler',1931);
insert into person values
    ('00001322','Michael','Ballhaus',1935);
insert into person values
    ('00001323','Thelma','Schoonmaker',1940);
insert into person values
    ('00001324','Gillian','Armstrong',1950);
insert into person values
    ('00001325','Lousia','Alcott',1832);
insert into person values
    ('00001326','Gabriel','Byrne',1950);
insert into person values
    ('00001327','Trini','Alvarado',1967);
insert into person values
    ('00001328','Denise','DiNovi',1955);
insert into person values
    ('00001329','Geoffrey','Simpson',1961);
insert into person values
    ('00001330','Nicholas','Beauman',1965);
insert into person values
    ('00001331','Jon','Turteltaub',1964);
insert into person values
    ('00001332','Daniel','Sullivan',1939);
insert into person values
    ('00001333','Sandra','Bullock',1964);
insert into person values
    ('00001334','Bill','Pullman',1953);
insert into person values
    ('00001335','Roger','Birnbaum',1954);
insert into person values
    ('00001336','Bruce','Green',1952);
insert into person values
    ('00001337','Cathy','Sandrich',1961);


